# Email Triage Rulebook

Complete rules, thresholds, and worked examples for the email-cleanup-triage skill. Read before a real cleanup, when a classification is disputed, or when configuring recurring sweeps.

## The Ten Rules

1. **Never-spam, never-delete categories.** Government agencies, VA/veterans, disability and benefits, class-action and settlement claims the user filed in, active case correspondence (law firm updates, medical appointment and post-op mail, travel itineraries, records-gathering services), and any sender the user consistently opens. These override every other signal, including volume, labels, and unread status.
2. **Content before labels.** Genuine correspondence can look exactly like marketing. A law firm's case updates, a surgery center's reminders, and a records service's "gather finished" notices have all been mislabeled as spam by volume-based sweeps. Read sender and body before applying any spam label.
3. **Open-ratio is the master signal.** Per sender: consistently opened (near 100% read) = important, keep visible, never bury. Consistently unopened = spam candidate. This ratio overrides label counts.
4. **Multi-label = user-marked important.** A message carrying several of the user's own category labels (Money, Receipt, Vehicle Sale, Action Required, Needs Reply, etc.) was deliberately flagged. Exception: if the same sender's mail is consistently unopened, the ratio wins.
5. **Bulk-unopened = confirmed spam.** Roughly 20 or more emails from one sender with none or almost none opened. Example threshold data: 29/36, 27/37, 26/31, 19/20 unopened — all confirmed.
6. **Always-spam categories.** Credit card offers (user needs no credit card), crypto platform promotions (treated as scams), loan lead-gen with rotating brand names and personal-name senders, job bait ("Career Notice", "immediate employment"), benefit-claim scams, adult content, psychic/medium mail, payment-verification phishing, and spoofed From names (same sending address behind different brand disguises).
7. **Multiple confirmations = auto-label.** Two or more independent signals (bulk-unopened + known spam category, most-wanted sender + never opened) put spam probability at 90%+. Apply the trashcan label without further review.
8. **Survival rule.** Old mail that has survived years of use and many cleanups without deletion has proven itself important. Never delete or spam-label it.
9. **One-time codes.** OTP/verification emails are useless after one use. File under a Notifications label or archive; never keep in the inbox.
10. **Trashcan label, never API deletion.** The spam label ("Likely Spam") is a trashcan: confirmed junk is consolidated there, and it equals deletion for the user because one Select-all → Delete empties it. The agent labels and archives; only the owner deletes. Nothing is lost until the owner chooses.

## Operating Notes

- **Result caps.** Email search returns about 100 results per query even when more exist. Paginate with cursors; when a pool is larger, partition by date ranges (split each range until it returns under 100). Always re-sweep after removals — messages hidden behind the cap surface only after earlier ones clear. A pool that looks like 100 can be 400+.
- **Consolidate by sender.** For each confirmed spam sender, search the entire account (from:sender), then apply the trashcan label to every message, including mail outside the current spam pile.
- **Built-in Spam folder.** The provider's own spam folder is separate from labels and cannot be modified via API. List its contents for the user and have them tap "Not spam" on anything worth keeping. Note: providers auto-delete spam-folder mail after ~30 days.
- **Stale mobile cache.** If the user reports a removed label still visible, verify server-side state first; mobile apps cache label badges. Advise pull-to-refresh or an app restart.
- **Unsubscribe links.** Encoded redirect unsubscribe links in old marketing emails are often expired. Prefer the mail client's built-in Unsubscribe button.

## Most-Wanted List (example from a real cleanup)

Auto-reject senders, labeled on sight with no review: loan lead-gen clusters (rotating names like FinlogixConnect, Indestata, InstallmentNexus), job bait (phenomenalwork.net, Jobs2Careers), benefit scams (Single Parents Alliance), crypto promos (BYDFi), trading promos, adult content, psychic mail, out-of-area dealer ad networks, and driver-contract ad blasts the user never opens.

## Worked Examples

- **The receipt mislabel.** An order confirmation from a verified brand carried Money/Receipt/Vehicle labels plus a stray spam label from a dealer-mail sweep. Fix: strip only the spam label; the sweep had lumped transactional mail with dealer marketing.
- **The law firm rescue.** Case mail ("Thank you for retaining our firm", adjuster updates, demand letters) sat in a spam pile with no other labels because the sender domain looked like marketing. Fix: read content, pull all case mail, label Informational. One message was starred — stars always mean important.
- **The settlement claim.** Class-action claim confirmation and payment-validation mail looked like phishing. The user had actually filed. Fix: confirm with the user before treating settlement mail as junk; label Money + Informational.
- **The reversal.** Driver-contract ads carried Vehicle Sale labels but were 19/27 unopened. The user confirmed disinterest. Fix: ratio beats labels — re-apply the spam label and remove the category label.
- **The hidden pool.** A spam label showed 100 messages; partitioned re-sweeps revealed 740 total, of which 425 were mislabeled and rescued. Fix: never trust the first page count.
