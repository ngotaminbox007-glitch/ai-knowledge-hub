---
name: photo-document-library
description: "Organize a photo library or cloud storage (Google Drive, Dropbox, iCloud/Google Photos export) where screenshots and photos are really documents in disguise: driver licenses, SS cards, passports, bank cards, statements, tax forms. Use when the user asks to organize, index, categorize, restructure, or replicate their document-photo library in a new location — e.g. 'organize this like my library', 'set up the categories here', or 'sort these screenshots into categories'."
metadata:
  version: '1.0'
  author: 'Built from Tam Ngo''s document organization sessions'
---

# Photo-Document Library Organizer

## When to Use

- The user asks to organize, index, or categorize photos, screenshots, Drive, Dropbox, or a new storage location
- The user says "like my library", "like before", "the categories", "restructure this new location identical"
- A library of 10k+ photos contains documents disguised as photos (screenshots of cards, IDs, forms)

## Core Philosophy

The user's library metaphor: a real library never dumps 10,000 books in the middle of the floor.
Every book has exactly one correct, indexed location, and any person can find it. Every photo is
a **document in disguise** — a screenshot of a pay stub is a pay stub. The purpose is findability:
"Tyler's SS card, Lisa's birth certificate, the 2024 tax return, the last five W-2s, Mom's debit
card screenshot from seven months ago" must each be findable in seconds, not by scrolling 29,000
chronological photos.

## Non-Negotiable Rules

1. **Approval gate**: never delete, send, or submit anything without the user's explicit "YES".
2. **Archive, never delete**: duplicates and bad copies go to the Review folder (staging for the
   user's own deletion review). Storage is sufficient — nothing is destroyed.
3. **One best copy per unique document** lives in its category. All duplicates/bad copies → Review.
4. **One exact location per file.** No file lives in two category folders.
5. **Content determines category, never the filename.** Open and read every document.
6. **Per-person labeling**: every document gets the person's name read from the document itself.
7. **Originals stay untouched**: iCloud/Google Photos hold the complete masters and are never
   modified. Drive/Dropbox hold a curated selection of important documents only.
8. **Real photos and memories are separate** from memes, TikTok saves, and social-media
   screenshots — the latter get their own isolated category.
9. **Zero guesswork**: if a name, number, or date can't be read, leave it blank and prefix the
   file "OPEN —". Never infer or reconstruct.
10. **Sensitive-data rule**: never output or write full SSNs, card numbers, CVVs, or passwords.
    Labels use last-4 only (e.g. "•2054").
11. **Front/back pairing**: card and ID fronts and backs are photographed seconds apart in the
    same session — pair them by capture time. An unmatched back still gets filed with that card.
12. **VIP documents get a secure location plus a backup copy** (vault + Box/second location).
    Transcripts, DD-214, naturalization certificates are irreplaceable.

## Category Tree (summary)

Full tree with subfolders: read `references/category-tree.md` before creating folders.

- 🪪 IDs & Licenses (by state: CA/AZ/LA; VA & Veteran IDs; Family Identification with per-person subfolders)
- 🛂 Passports (per person; applications & forms subfolder)
- 🟦 Social Security Card (per person)
- 💳 Credit & Debit Cards (per person; open items at root)
- 🏦 Bank & Finance (Tax Returns & Filings, W-2s, 1099s, IRS Transcripts & Notices, Paystubs, Checks)
- 🔐 Logins & Credentials (private area only)
- 📸 Real Photos & Memories
- 🎭 Memes & Social Saves (TikTok, memes, fun screenshots — isolated)
- 🧾 Receipts
- 🎓 School & Academics
- 🏥 Medical & Insurance
- 🚗 Vehicle & Auto
- 🗳️ VA Generated (AI-drafted letters/statements never sent to VA)
- ♻️ Bad Copies & Duplicates — Review (staging, never delete)
- 🏛️ VIP Best Copies vault (VA Benefits, SCCHA, Service Records, IDs & Certificates, Academics, Career)

## Workflow (the algorithm)

1. **Inventory**: search the location by keyword per category (card, license, passport, statement,
   W-2, 1099, transcript...). Collect id|name|parents for every hit. Expect the same document type
   scattered across 20 years with no pattern.
2. **Download & convert**: download each file; convert HEIC→JPG with `magick` for viewing
   (some .jpg files are secretly HEIC — check with `magick identify`). PDFs and MP4s can't be
   viewed directly — convert PDFs to JPG, note videos by name.
3. **Read in batches of ~10** with structured output: one line per image
   `FILENAME | key facts | person | READABLE/BLURRY`. Extract per document type — see
   `references/reading-and-labeling.md`.
4. **Identify duplicates** (same card photographed twice, crops, app screenshots of the same card).
   Keep the best physical photo; rest → Review.
5. **Create the folder structure** from the category tree (per-person subfolders as needed).
6. **Move + rename** each file to its one location with its final label.
7. **Verify**: re-list each destination folder and confirm counts. Report moved/kept/reviewed.
8. **Report with one immediate next step** and a list of OPEN items for the user to resolve.

## Naming Conventions

- Keeper: `Person — Document Type •last4 (front/back).ext`
  e.g. `Tam T Ngo — AZ DL •D02417322 (front, exp 2033).jpg`
- Household doc: `Tam & Lisa — 2022 Tax Return.pdf`
- Unverified: `OPEN — Bread Credit •5655 — Ly Huynh (verify: Mom or Ly'on).jpg`
- Duplicate: `DUP — First Tech Debit •3580 (screenshot of same card).png`
- Screenshot of UI with no document value: `ARCHIVE — Cloud folder list screenshot.png`

## References

- `references/category-tree.md` — full folder tree, subfolders, and where each document type goes
- `references/reading-and-labeling.md` — what to extract from each document type; institutions
  catalog (banks, agencies) for identification; sensitive-data handling
- `references/drive-tooling.md` — exact Google Drive CLI patterns (search, download, move+rename,
  HEIC conversion) proven to work, including the string-params gotcha
- `references/recommendations-and-open-items.md` — standing recommendations (takeout, per-person
  tax labels, masked galleries, backups) and open items carried over from the original library
