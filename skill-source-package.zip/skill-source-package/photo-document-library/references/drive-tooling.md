# Drive Tooling — Exact Working Patterns

Google Drive via the `gws` CLI. These exact patterns are proven; deviating from them caused
failed moves (arrays stringified, 404s from wrong IDs).

## Search (collect id|name|parents)

```bash
cat > /tmp/s.json << 'EOF'
{"q": "name contains 'Passport' and trashed = false", "fields": "files(id,name,parents,mimeType)", "pageSize": 100}
EOF
gws drive files list --params "$(cat /tmp/s.json)" 2>&1 | python3 -c "
import json,sys
d = json.load(sys.stdin)
for f in d.get('files', []):
    print(f['id'] + '|' + f['name'] + '|' + ','.join(f.get('parents', [])))"
```

Run one term per loop (Passport, debit, credit card, bank statement, W-2, 1099, transcript,
license, SSN...), then `sort -u -t'|' -k1,1` to merge. Note: `name contains` can match file
content too — always verify hits are the right type before moving.

## Create folder

```bash
cat > /tmp/c.json << 'EOF'
{"name": "🛂 Passports", "mimeType": "application/vnd.google-apps.folder", "parents": ["<parentFolderId>"]}
EOF
gws drive files create --json "$(cat /tmp/c.json)"
```

## Download file (media)

```bash
gws drive files get --params '{"fileId": "<ID>", "alt": "media"}' --output "raw/<name>"
```
The output path must be inside the workspace.

## Move + rename — CRITICAL: parents are STRINGS, not arrays

```bash
gws drive files update --params '{"fileId": "<ID>", "addParents": "<destFolderId>", "removeParents": "<oldFolderId>"}' --json '{"name": "New Name — with details.ext"}'
```

Gotchas hit and fixed:
- Array values for addParents/removeParents get stringified and the update fails — use plain strings.
- Apostrophes in names (Ly'on) break `name = '...'` queries — search with `name contains 'fragment'`
  instead, or rename by ID directly.
- Hash-named files (content hashes as filename) are common — identify by viewing, then rename
  meaningfully. The hash is the NAME, not the file ID; get the real ID from the search result.
- Basename collisions: two files differing only by extension (photo.heic + photo.png) — when
  matching moves by basename, `head -1` can grab the wrong one and one file gets moved twice.
  Match on full original filename including extension.
- HEIC files disguised as .jpg: check with `magick identify` before assuming; rename keeps its
  true extension.

## HEIC → JPG for viewing

```bash
magick "raw/photo.heic" -auto-orient -resize 1400x1400 "view/photo.jpg"
```
- PDFs: some fail conversion — note and skip.
- MP4s: not viewable — file by name only.
- view_images: batches of ~10, exact workspace paths, numbered list in the prompt.

## Verify after moves

Re-list each destination folder (`'<folderId>' in parents and trashed = false`) and confirm the
file count and names. Report moved/kept/reviewed plus OPEN items.
