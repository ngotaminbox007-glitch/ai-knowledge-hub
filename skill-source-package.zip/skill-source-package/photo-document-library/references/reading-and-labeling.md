# Reading & Labeling Documents

What to extract from each document type when viewing photos in batches. Read the document itself,
never the filename. Never output or record full SSNs, card numbers, CVVs, or passwords — last-4 only.

## Batch-reading protocol

- View ~10 images per batch, each batch with a numbered list and one structured line per image:
  `FILENAME | key facts | person | READABLE or BLURRY`
- Ask for a "same card/document photographed twice" note at the end of each batch.
- Re-view unclear images individually with a focused prompt before deciding.
- If a field can't be read, record NR — never guess.

## Per-document extraction

| Document | Extract |
|---|---|
| Driver license / state ID | state, issue date, expiry, class (C, M1, CDL-A), designations (VETERAN, REAL ID), person, license number last-4 |
| SS card | person, last-4, issue/reissue year if visible |
| Passport | person, country (US/Vietnam), issue & expiry dates, type (adult/child), application vs data page |
| Bank card | issuer, debit/credit/virtual/business, person, last-4, physical photo vs app screenshot, front/back |
| Check | bank, person, check number, blank vs filled |
| Statement | bank, person, period (month/year), account type |
| W-2 / 1099 | person, employer/payer, tax year |
| Tax return | person(s)/household, tax year |
| Pay stub / time ticket | person, employer, pay period |
| Transcript (school/military) | person, institution — VIP, irreplaceable |
| Login credential screenshot | service/app only — never the credential itself |

## Front/back pairing

Fronts and backs are captured seconds apart in one session. Pair by capture date and visual match.
If a back has no matching front, file it with that card's entry anyway — that may be the only
record of the back.

## Duplicate detection

Same card/document appearing in multiple photos is the norm (SS card re-photographed for 20 years,
14 licenses across 3 states). Keep the best copy — prefer a physical photo over an app screenshot,
higher resolution over lower, front and back both kept. Everything else → Review as `DUP —`.

## Institutions catalog (for identification)

Banks/issuers seen: Bank of America, Merrill, Wells Fargo, Wells Fargo Auto, Chase, First Tech
Federal Credit Union, DCU (Digital Federal CU), Desert Financial CU, Varo, Chime, GO2bank, Novo,
Mercury, Bread, PayPal Business, One, Current, Branch, MoneyLion RoarMoney, Fortiva, USAA, BMO,
AZ DES Way2Go, Commonwealth of Virginia (Wells Fargo fiscal agent).

Agencies: CA/AZ/LA DMVs & OMVs, SSA, US State Dept (passports), VA, SCCHA, EDD, IRS.

Household names may appear as variants (Ly/Lyon/Ly'on Huynh; Lisa Nguyen/Lisa Thi Nguyen) —
verify against the roster before assigning a person; when ambiguous, mark OPEN.

## Verification & review workflow

1. Organize and label everything (best copies in categories, dupes in Review).
2. Present the user a verification list: what moved where, with final names.
3. User reviews and may mark items as irrelevant/unnecessary.
4. Marked items are staged for deletion — deleted only after the user's explicit "YES".
5. VIP documents get a backup copy in a second secure location (vault + Box).
