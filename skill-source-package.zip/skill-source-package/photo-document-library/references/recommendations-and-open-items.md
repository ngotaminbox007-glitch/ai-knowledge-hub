# Recommendations & Open Items

Recommendations made during the original organization (2026-11), preserved for the next location.

## Standing recommendations

1. **Google Photos bulk import**: the 29,000-photo master library can only be fully sorted via
   takeout.google.com export → "Add to Drive", then processing the export folder with this skill.
   Folder-level Drive search finds scattered copies but not everything.
2. **Per-person tax labeling**: W-2s, 1099s, and returns should each carry the person's name read
   from the form (e.g. "Tam T Ngo — W-2 Danos 2022"); household returns labeled "Tam & Lisa — 2022".
3. **Masked public gallery**: the Driver License History site pattern works well, but card/SSN
   images are Tier 1 — publish only redacted thumbnails (last-4, masked numbers), or keep the
   gallery local/private.
4. **Backup copies**: VIP documents (transcripts, DD-214, naturalization, VA awards, SCCHA packet)
   live in the vault with a second copy in Box. New VIPs found during organizing get the same
   dual-home treatment.
5. **Archive over delete**: with sufficient storage, everything superseded goes to Review and
   stays there until the user explicitly approves deletion.
6. **Review pass**: after each organizing run, give the user a verification list; they mark items
   irrelevant/unnecessary; deletion happens only on explicit "YES".

## Open items from the original library (carry forward)

- **Passports**: 11 passport files identified and read (Tam US+Vietnam 2015; Tyler child passport
  2015–2020; Mom US passport 2019–2029; Cathy child passport 2014; Lauren DS-11 application 2026;
  DS-11 forms; online renewal confirmation July 2026; blurry passport in folder — OPEN) but the
  🛂 Passports folder tree and moves were not yet created. Do this first at the next location.
- **Bank statements & routing/checking screenshots**: ~100 files found, not yet sorted by bank and
  person. Pattern: group by bank (BofA, Varo, First Tech, DCU, USAA, BMO...), label with period.
- **"LY HUYNH" cards** (Bread •5655, Desert Financial •9788): ambiguous between Mom and Ly'on —
  needs the user to confirm.
- **Unknown-bank card back** (2023-06-02, CVV visible): issuer never identified — OPEN.
- **AZ license DOB 08/03/1979**: unknown card in Arizona Licenses — flagged "verify".
- **iCloud folders still to sort**: icloud_upload_run2, duplicate folder, iCloud_leftovers.
- **Google Photos 29k library**: awaiting takeout export.
- **Tax-doc per-person labeling**: W-2s, 1099s, returns still need person names read from forms.
