# Category Tree — Full Structure

Recreate this tree identically in any new location. Root folder: **Photos by Category**.
Emoji prefixes are part of the folder name. Per-person subfolders are created as needed from the
household roster below.

## Household roster (labels read from documents)

| Label | Relationship |
|---|---|
| Tam T Ngo | the user |
| Lisa Thi Nguyen | spouse |
| Lauren Ngo | child |
| Tyler Thanh Ngo | child |
| Cathy Nguyen | family |
| Ly Tuyet Huynh (Mom) | mother |
| Ut Thi Nguyen | family |
| Dung Nguyen | family |
| Ly'on Huynh | family member |
| Tuu Thanh Huynh | family member |
| Pham (Hong-Nguyen T Pham, Vu H Pham) | extended family — flag OPEN until confirmed |

When a card reads a name variant ("LY HUYNH", "LYON HUYNH"), do not guess between people —
file at the category root with an `OPEN —` prefix and "(verify: X or Y)".

## Tree

```
Photos by Category/
├── 🪪 IDs & Licenses/
│   ├── California/            # Tam's CA licenses & IDs
│   ├── Arizona/              # Tam's AZ licenses & IDs (incl. CDL)
│   ├── Louisiana/            # Tam's LA licenses & IDs
│   ├── VA & Veteran IDs/     # VA cards, veteran designations
│   └── Family Identification/
│       ├── Lisa Thi Nguyen/
│       ├── Ly Tuyet Huynh (Mom)/
│       ├── Ly'on Huynh/
│       └── Tuu Thanh Huynh/
├── 🛂 Passports/
│   ├── Tam T Ngo/
│   ├── (per person as found)/
│   └── Applications & Forms/ # DS-11 forms, renewal confirmations
├── 🟦 Social Security Card/
│   ├── Tam T Ngo/
│   └── (per person)/         # one folder per person on the card
├── 💳 Credit & Debit Cards/
│   ├── Tam T Ngo/
│   ├── Lisa Thi Nguyen/
│   ├── Ly Tuyet Huynh (Mom)/
│   ├── Ly'on Huynh/
│   └── (root holds OPEN — unverified-person cards)
├── 🏦 Bank & Finance/
│   ├── Tax Returns & Filings/
│   ├── W-2s & Wage Statements/
│   ├── 1099s & Gig Income/
│   ├── IRS Transcripts & Notices/
│   ├── Paystubs/
│   └── Checks & Check Images/
├── 🔐 Logins & Credentials/   # inside the private ID area, never public
├── 📸 Real Photos & Memories/ # genuine photos of people, places, events
├── 🎭 Memes & Social Saves/   # TikTok saves, memes, funny screenshots — isolated
├── 🧾 Receipts/
├── 🎓 School & Academics/
├── 🏥 Medical & Insurance/
├── 🚗 Vehicle & Auto/
├── 🗳️ VA Generated/           # AI-drafted letters/statements never sent to VA
├── ♻️ Bad Copies & Duplicates — Review/   # staging area, NEVER delete
└── 🏛️ VIP Best Copies (vault)/
    ├── VA Benefits/
    ├── SCCHA/
    ├── Service Records/
    ├── IDs & Certificates/
    ├── Academics/
    └── Career/
```

## Where each document type goes

| Document | Location |
|---|---|
| Driver license / state ID (user) | 🪪 IDs & Licenses → state folder |
| Family member's license | 🪪 IDs & Licenses → Family Identification → person |
| Passport data page / application | 🛂 Passports → person (or Applications & Forms) |
| SS card photo | 🟦 Social Security Card → person |
| Debit/credit card photo or app screenshot | 💳 Credit & Debit Cards → person |
| Bank statement, routing/checking details | 🏦 Bank & Finance (per bank, per year) |
| W-2, 1099, tax return | 🏦 Bank & Finance subfolders, labeled with the person |
| Pay stub, time ticket | 🏦 Bank & Finance → Paystubs |
| Birth certificate, naturalization, citizenship | 🏛️ vault → IDs & Certificates |
| Military transcript, DD-214 | 🏛️ vault → Service Records (VIP, irreplaceable) |
| VA award letters, claim docs | 🏛️ vault → VA Benefits |
| Housing/SCCHA documents | 🏛️ vault → SCCHA |
| Login/password screenshot | 🔐 Logins & Credentials |
| Receipt | 🧾 Receipts |
| TikTok/meme/fun screenshot | 🎭 Memes & Social Saves |
| Real photo of people/places | 📸 Real Photos & Memories |
| Screenshot of a file browser or UI (no doc value) | ♻️ Review, prefixed ARCHIVE — |

## Dual-tier rule

Tier 1 (full numbers, high-res masters) stays in private storage (vault, private ID area) and never
leaves. Tier 2 (last-4, redacted) is the only version used for correspondence or published sites.
Card and SSN images are Tier 1 — never publish them to a shareable site unredacted.
