---
name: visual-document-cleanup
description: "Visual-only cleanup of scanned official documents — deskew, contrast, ink cleanup, signature placement — under strict no-alteration rules with dual-tier redaction and an approval gate. Use for NEW DOC requests and scans of VA forms, DD-214, IDs, or Social Security cards. Not for rewriting text or drafting new documents."
---

# Visual Document Cleanup (NEW DOC)

## When to Use This Skill

The user says "NEW DOC", asks to clean up, remaster, or brighten a scan of an official document, or needs a signature merged onto a form page. Typical sources: VA forms (e.g., 21P-509), DD-214, Social Security card, state ID, signed housing packets.

Do not use when the user wants text rewritten or a new document drafted — that violates the non-alteration rules below.

## Non-Alteration Rules (binding)

- Visual-only operations. Never rewrite, retype, or regenerate official form text; never move, resize, or redraw layout boundaries.
- Never infer, guess, or reconstruct missing, obscured, or partially covered numbers (SSNs, dates, claim IDs, license numbers). Leave blank, mark the item open, and ask the user.
- Never submit, send, file, or delete any document without the user's explicit "YES." Previews and drafts are fine.

## Workflow

1. INTAKE — Identify the project track and collect the highest-resolution originals available. Work from copies; keep the originals untouched.
2. VERIFY — List what the user wants changed and check each operation against the non-alteration rules. Flag anything that would alter text, layout, or data.
3. PREPARE — Apply only these visual operations: deskew/rotate, contrast and brightness, noise/dust removal, crop to original boundaries, ink-tone cleanup, removing form lines behind handwriting while preserving the cursive strokes, merging a signature image into a form box aligned to that box's baseline.
4. QUALITY CHECK — Confirm: page count matches; signature sits on the box baseline; pages that should stay untouched are untouched; enclosures match the Master Index when part of a packet.
5. APPROVAL GATE — Present a before/after preview and wait for the explicit "YES."
6. ARCHIVE & LOG — File dual-tier: full-number master in private storage (Tam_Archive / private Notion vault), never shared; redacted outbound copy (last 4 digits only, sensitive IDs blacked out) for anything leaving the vault. Update the index, log verified facts separately from open items, and end the update with one immediate next step.

## Failure and remedy

- Obscured or partially covered number: leave it blank, mark open, ask the user. Do not reconstruct.
- Preview shows altered text or shifted boundaries: discard the candidate, restart from the pristine original.
- User has not approved: nothing leaves the workspace, regardless of deadline pressure.

## Examples

Input: "NEW DOC: clean up my DD-214 scan" — deskew, contrast, dust removal only; produce the Tier 1 master and a Tier 2 redacted copy; wait for "YES" before anything is uploaded or sent.

Input: "merge my signature into box 11B" — align the signature to the 11B baseline, remove form lines behind the cursive, leave Item 11A and every other field untouched, present the preview.
