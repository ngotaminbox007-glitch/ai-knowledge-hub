---
name: gmail-inbox-triage
description: "Triage and organize a Gmail inbox with strict routing rules: keep active institutional correspondence (VA, housing authority, school, banking) visible in the Inbox, label and archive lower-value mail in batched sweeps, and never delete without approval. Use when the user asks to clean up, organize, sweep, or triage their Gmail inbox or apply their label system. Not for composing emails or deleting mail."
metadata:
  perplexity:
    connectors:
      - id: gcal
        reason: Gmail is reached through this connector; triage reads and labels messages through it.
---

# Gmail Inbox Triage

## When to Use This Skill

Run this when the user asks to clean up or organize their Gmail inbox, apply the label system, or run an inbox sweep. The system was trained over multiple sessions; follow it exactly rather than improvising categories.

## The Routing Architecture (binding)

- **The Inbox is restricted to active institutional correspondence.** Never route emails from the housing authority (SCCHA), the VA, educational institutions, or primary banking institutions out of the main Inbox without the user's direct review.
- **Six standard labels, applied in this order of meaning:**
  1. Receipts and Financial — rent, auto/rideshare expenses, tuition, utility confirmations
  2. Shopping & Promos — retail, discounts, commercial offers
  3. Accounts & Security — 2FA codes, login alerts, password notices
  4. Automated Alert (Code/Work) — GitHub, Cursor, developer notifications
  5. Informational — general newsletters, civic updates, non-action items
  6. Likely Spam — auto-dealership solicitations, cold inquiries, bulk junk
- **Archive, never delete.** Lower-value messages are labeled and archived, staying available in All Mail. Zero unapproved deletions — deletion requires the user's explicit "YES."
- **Leave suspicious or security-sensitive items in the Inbox** for the user's manual review rather than auto-filing them.

## Workflow

1. **SURVEY** — Read the inbox state. Note the message count and roughly how many fall into each label.
2. **PROTECT FIRST** — Identify consequential mail (VA, housing, banking, school, work, security-sensitive). These stay visible in the Inbox.
3. **SWEEP IN BATCHES** — Gmail's view limit is 100 messages per pass. Work in multiple passes (a ~210-message cleanup takes about three passes). Apply labels, then archive.
4. **INDEX** — Record the outcome in the Notion Inbox Index: kept, archived, and review-needed mail, with pass counts and totals.
5. **REPORT** — End with counts (archived, kept, review-needed), the review-needed list for the user, and one immediate next step.

## Failure and Remedy

- A message's category is unclear: label it Informational and add it to the review-needed list rather than guessing.
- A consequential sender appears in a low-value label: unlabel it, return it to the Inbox, and flag it.
- Deletion pressure from the user mid-sweep: still require the explicit "YES" before anything is destroyed.

## Example

Input: "Clean up my Gmail inbox."
Output: three passes over ~210 messages; ~200 archived under the six labels; VA, SCCHA, bank, and school mail left in the Inbox; 5 suspicious items listed for manual review; Inbox Index updated; no deletions.
