---
name: benefit-verification-summary
description: "Turn benefit award letters and VA decision notices into a clean, housing-ready verification summary for SCCHA or similar agencies. Use when the user asks for a benefit verification summary, proof of benefits, or a benefits/income letter for housing. Not for claims strategy, disputes, or medical detail."
metadata:
  version: '1.0'
  source: Benefit Verification Summary Space (incorporated Nov 1, 2026)
---

# Benefit Verification Summary

## When to Use This Skill

Use this skill when the user asks to:

- Turn benefit award documents, VA letters, or decision notices into a verification summary
- Write a proof-of-benefits or benefit summary letter for a housing authority (e.g., SCCHA) or similar agency
- Summarize benefit status, payment amounts, or dependents for a third-party verifier

## Instructions

1. **Identify sources.** Work only from documents the user provides or points to (award letters, decision notices, the VA award history). Note each fact's source document. If no source document exists for a fact, do not include it — mark it as an open item instead.
2. **Extract only verification facts:** official benefit status, effective dates, dependents (if relevant to the recipient), and any other fact the recipient needs. Omit internal claim disputes, medical detail, and background narrative unless the user asks for them. **Never state payment or income amounts in housing-facing summaries** — the user does not want income or benefit amounts shared with housing authorities; include a dollar figure only when the user explicitly asks for it.
3. **Zero guesswork on numbers.** Never infer, guess, or reconstruct missing or partially obscured numbers (SSNs, claim IDs, amounts, dates). Leave the field blank, mark it open, and ask the user for the value.
4. **Draft in plain, professional language** that an agency worker can act on directly. Tailor wording to the named recipient and purpose; include only facts that support verification.
5. **Separate verified facts from open items** in the draft, and end with a one-line list of anything still missing.
6. **Redact before anything leaves the workspace.** Outbound copies use last 4 digits only with sensitive IDs blacked out. Full-number originals never leave the vault.
7. **Stop at the approval gate.** Present the draft for review. Nothing is sent, filed, or transmitted to any agency without the user's explicit "YES."

## Output Example

```markdown
BENEFIT VERIFICATION SUMMARY
Prepared for: Santa Clara County Housing Authority (SCCHA)
Purpose: Household income and benefit verification

Benefit program: U.S. Department of Veterans Affairs compensation
Current status: [Active — per award letter dated YYYY-MM-DD]
Effective date: [YYYY-MM-DD]
Dependents counted: [names/relationships if relevant to recipient]
(No payment amounts — omitted per the user's standing rule unless they ask.)

Source documents:
- [Award letter, date]
- [Decision notice, date]

Open items (not yet verified):
- [Any fact lacking a source document]
```
