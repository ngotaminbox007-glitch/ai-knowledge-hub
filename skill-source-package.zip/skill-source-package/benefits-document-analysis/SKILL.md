---
name: benefits-document-analysis
description: "Analyze government-benefit documents into the user's structured trackers: the VA Benefits folder feeds the Government Benefits Tracker (eligibility, forms, contacts, action items, deadlines), and the SCCHA folder, its subfolders, and qualifying government-benefit emails feed the Benefits Insights Tracker with structured program findings. Use when the user asks to analyze benefit documents, process new files in those folders, or update the trackers. Not for drafting agency inquiry emails or searching the web for new programs."
metadata:
  perplexity:
    connectors:
      - id: google_drive
        reason: Reads the VA Benefits and SCCHA folders and holds the Government Benefits and Benefits Insights trackers.
      - id: gcal
        reason: Gmail is reached through this connector; qualifying government-benefit emails are read from it.
---

# Benefits Document Analysis

## When to Use This Skill

Run this when the user asks to analyze benefit documents, process new files in the watched folders, or update the benefits trackers. Two watched scopes exist — decide which one this run covers:

- **VA Benefits folder** feeds the **Government Benefits Tracker**.
- **SCCHA folder, its subfolders, and qualifying government-benefit emails** feed the **Benefits Insights Tracker**.

## Instructions

1. Identify the scope from the request or from where the new documents are; if both folders have new material, handle each scope against its own tracker.
2. Read each new or unprocessed document in the watched location, including qualifying government-benefit emails for the SCCHA scope.
3. Extract into the matching tracker: program findings, eligibility, forms, contacts, action items, and deadlines for the Government Benefits Tracker; structured program findings for the Benefits Insights Tracker.
4. Update only the designated tracker. Record which documents were processed so the next run can skip them. Do not alter the source documents or other files.
5. Zero guesswork: if a number, date, or ID is missing or unreadable, mark it as an open item for the user rather than inferring it.
6. Do not send messages, submit forms, or contact agencies; trackers are updated in place and findings reported in the session. Separate verified facts from open items in every update.

## Example

Input: "Analyze the new files in my VA Benefits folder."
Output: a note that three new documents were processed into the Government Benefits Tracker, a short list of extracted action items and deadlines, and any open items — for example, "letter references a claim number not shown in the scan — left blank for the user to supply."
