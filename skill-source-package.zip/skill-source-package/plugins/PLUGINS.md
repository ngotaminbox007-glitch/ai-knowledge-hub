# Plugins — Status and Path

**Reader:** You are an AI agent or a person. This file documents the plugin layer of this package.

## What a Plugin Is

A plugin is a bundle that packages one or more skills together with their connector declarations so they install as a single unit. A plugin can bundle skills and connectors; skills may also belong to no plugin.

## Current Status: No Custom Plugins Exist

As of November 4, 2026, Tam's account has zero custom plugins. The complete custom inventory is 13 standalone skills (in this package), 3 automation instructions, 17 platform connectors, and 14 built-in abilities. The plugin category in the Notion inventory has no rows.

## This Package as a Plugin-Ready Bundle

This package is structured so it can function as one installable unit even though it is not a registered plugin:

```
skill-source-package/
├── README.md            <- install manual (start here)
├── skills (13 folders)   <- each with SKILL.md
├── automations/          <- 3 scheduled-task instructions
├── connections/          <- connector setup guide + dependency map
└── plugins/              <- this file
```

To treat the whole package as a single plugin-style install: install all 13 skill folders per the README, connect the three required connectors per `connections/CONNECTORS.md` (google_drive, gcal, notion_mcp), and schedule the three automation files if recurring runs are wanted.

## If a Real Plugin Is Wanted Later

A future plugin could bundle, for example, the four veteran-workflow skills (service-records-review, veteran-program-monitor, veteran-education-search, benefits-document-analysis) plus their connector declarations (google_drive, gcal) into one "veteran-workflows" plugin. Build it when the platform's plugin registration is available to this account; the source in this package is everything such a plugin would contain.
