---
name: master-archive-organization
description: "Organize a personal master archive and dual-tier document vault: numbered category folders (housing, VA claims, master vault, career, academics, financial), Tier 1 private full-copy and Tier 2 redacted outbound vaults, and case folders with a Master Index and separate enclosures. Use when the user asks to set up, replicate, or reorganize their master archive or document vault structure. Not for inbox triage or photo library sorting."
metadata:
  perplexity:
    connectors:
      - id: google_drive
        reason: The master archive lives in Drive; folder creation and file placement run through it.
      - id: notion_mcp
        reason: Notion mirrors the archive as the tracking hub with tiered document records.
---

# Master Archive Organization

## When to Use This Skill

Run this when the user asks to set up, replicate, or reorganize their master archive — the numbered top-level folder system for all life-case records — or to build the dual-tier document vault inside it.

## The Structure (binding pattern)

```
MASTER ARCHIVE/
├── 01_HOUSING_<AGENCY>/        — Outbound_Packets, Medical_Verifications, Confirmations_and_Receipts
├── 02_VA_BENEFITS_CLAIMS/      — per-claim folders (forms, raw signatures, final merged PDFs, exams)
├── 03_MASTER_DOCUMENT_VAULT/
│   ├── Tier_1_Private_Full/    — master / high-res copies with full SSN and ID numbers
│   └── Tier_2_Outbound_Redacted/ — working copies for external submissions, last-4 only
├── 04_CAREER_/                 — applications, trade certs, OJT logs
├── 05_ACADEMICS_/              — per-course coursework folders
└── 06_FINANCIAL_AND_HOUSEHOLD/ — rent receipts, active billing statements
```

- **Packet folders** (inside a case): a dated response-packet folder containing a Master_Index, a Cover_and_Response, and Enclosures as separate numbered PDFs.
- **Division of labor:** Google Drive holds the master files; Notion is the tracking hub with tiered document records; Gmail is the communications gate.

## Binding Rules

- **Tiers never mix.** A full-number document never sits in the outbound tier; an outbound copy is always the redacted last-4 version.
- **Nothing moves to the outbound tier without the user's explicit "YES."**
- **Replication, not invention.** When the user says "organize this like my archive," mirror the existing numbered structure; do not design a new scheme.

## Workflow

1. **MAP THE EXISTING SYSTEM** — If an archive already exists, read its numbering and naming before creating anything.
2. **BUILD OR EXTEND** — Create numbered category folders and case subfolders following the pattern above.
3. **PLACE FILES** — File each document into its matching case folder; packets get Master_Index + cover + numbered enclosures.
4. **VAULT THE IDENTIFIERS** — Route ID-bearing documents into Tier 1 (private) or Tier 2 (redacted) according to the tier rules.
5. **REPORT** — Deliver the resulting tree, note where each file landed, flag anything that could not be placed confidently, and end with one immediate next step.

## Example

Input: "Set up my Drive archive for the new housing packet like the old one."
Output: 01_HOUSING folder extended with a dated Outbound_Packets folder containing Master_Index.pdf, Cover_and_Response.pdf, and Enclosures 01-10 as separate PDFs; confirmations folder created for the receipt; Tier 2 copies routed for the outbound set; next action: review the Master_Index against the enclosure list.
