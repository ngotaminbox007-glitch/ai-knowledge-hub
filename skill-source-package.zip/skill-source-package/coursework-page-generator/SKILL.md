---
name: coursework-page-generator
description: "Generate a coursework-help instructions page for a school, college, or apprenticeship program from a fixed template with placeholder variables and conditional rules. Use when the user asks to create, fill in, or revise a homework or coursework assignments page / project instructions for a specific institution. Not for doing the coursework itself, tutoring, or essay help."
metadata:
  author: tam-ngo
  version: '1.0'
---

# Coursework Page Generator

## When to Use This Skill

Use this skill when the user asks to:

- Create or generate a coursework/homework assignments page for a school, college, or trade program
- Fill in or adapt the institutional coursework template for a new institution
- Revise an existing assignments page so it stays consistent with the template

Do not use this skill for actual coursework help — writing, editing, solving, or checking assignments. This skill only produces the instructions pages that other projects then follow.

## Instructions

1. Read `templates/page-template.md` in full. It defines the placeholder variables, the fixed section texts, the page skeleton, conditional rules C1–C9, and the quality checks.
2. Gather the inputs: exact institution name, program type, task types, whether the user takes multiple courses, and output format. Verify the institution name spelling before use — web search if unfamiliar. Default to plain-text format when the page is destined for Perplexity project instructions.
3. Fill the variables and apply rules C1–C9. Omit optional sections rather than adding filler, and never invent institution-specific rules the user did not supply.
4. Assemble the page in the fixed section order from the template.
5. Run the quality checks, then deliver the page as a ready-to-paste plain-text or markdown block. Report which conditional rules fired and any addition made beyond the template, and flag dropped sections the user may want back.

## Input/Output Example

Input: "Make a coursework page for my ETASV Inside Wireman apprenticeship."

Output: a plain-text page titled "ETASV Inside Wireman apprenticeship assignments" — fixed sections kept verbatim, "essays" swapped for labs and code-theory assignments (rule C1), no scope-exclusion clause (C2), and "Preserve my wording and voice" dropped because the program is technical (C4), with the dropped section flagged so the user can restore it if written assignments appear.
