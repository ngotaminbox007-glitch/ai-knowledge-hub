---
name: veteran-program-monitor
description: "Weekly search for changes to California veteran housing and support programs, including documentation and reasonable-accommodation requirements and county veterans service offices statewide, with priority on Santa Clara and nearby counties. Use when the user asks to check for new or changed California veteran programs, housing support, VSO services, or accommodation rules. Not for education grants and scholarships or for analyzing the user's own benefit documents."
---

# Veteran Program Monitor

## When to Use This Skill

Run this when the user asks for the weekly California veteran-program check, new veteran housing or support programs, or county veterans service office updates. The user is a veteran in Santa Clara County with an active housing voucher and accommodation case, so housing-relevant items matter most.

## Instructions

1. Search for changes and new offerings in California veteran housing and support programs. Cover statewide programs plus county veterans service offices, prioritizing Santa Clara County and nearby counties.
2. For each program found, check and record: program name, administering agency, eligibility basics, documentation requirements, and any reasonable-accommodation provisions.
3. Prioritize items that affect housing vouchers, transfer paperwork, household updates, or accommodation requests; list others briefly.
4. Present findings as a short dated report with a source link for every program. Quote documentation and accommodation requirements from the official source, not from memory.
5. Do not submit applications, contact agencies, or draft messages to them unless the user explicitly asks in this session. Searching and reporting only.
6. Flag anything with a deadline or application window so the user can decide whether to act.

## Example

Input: "Any new California veteran housing programs this week?"
Output: a dated list of two or three programs, each with agency, eligibility, documentation requirements, deadline if any, and a source link, plus one line noting which items touch the user's current voucher case.
