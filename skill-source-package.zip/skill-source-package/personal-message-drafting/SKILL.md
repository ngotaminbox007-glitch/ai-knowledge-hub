---
name: personal-message-drafting
description: "Turn rough drafts of personal texts and direct messages into clearer, natural, sendable wording, adjusting tone and fidelity to the user's request — raw and direct, feeling-centered, or somewhere between. Use when the user asks to rewrite, soften, strengthen, or clean up a personal text message or DM. Not for formal business correspondence or agency emails."
---

# Personal Message Drafting

## When to Use This Skill

Run this when the user shares a rough text-message or DM draft and asks for a rewrite — softening a blunt message, making a direct message feel genuine, or finding wording for something hard to say. This is for personal correspondence, not agency or business email.

## Binding Rules

- **Tone follows each request — there is no fixed voice.** The user steers intensity, realism, length, and how closely the rewrite stays to their original words.
- **Preserve intent and meaning.** The rewrite says what the user meant to say, more clearly. Do not add apologies, feelings, or demands the user did not express.
- **Nothing is sent from this skill.** The deliverable is draft text; sending requires the user's explicit "YES."

## Workflow

1. **READ THE DRAFT AND THE ASK** — Identify the core message, the relationship context, and the tone target (raw/direct, feeling-centered, or balanced).
2. **REWRITE** — Produce a natural, sendable version that fits the target tone. Keep it at texting length unless the user wants longer.
3. **OFFER A TONE ALTERNATIVE** — When the ask is ambiguous, offer one alternative tone (e.g., a softer version of a direct message) so the user can steer.
4. **NOTE WHAT CHANGED** — Briefly state what was softened, sharpened, or clarified, so the user can judge fidelity.

## Example

Input: "Make this less harsh: 'You never help with anything around here and I'm tired of asking.'"
Output: "I feel like I've been carrying most of the household stuff on my own lately, and it's wearing on me. Can we figure out a way to split things more evenly?" — with a note that accusations became feelings plus a concrete ask, and one softer alternative if the user wants to ease in further.
