---
name: brand-inspiration
description: "Analyze competitor websites, capture creative examples, and build a visual reference deck with annotations on copy, CTAs, and positioning."
user-selectable: true
icon: telescope
metadata:
  perplexity:
    display_name: "Brand inspiration"
    display_description: "Analyze competitor websites, capture creative examples, and build a visual reference deck with annotations on copy, CTAs, and positioning."
  owners: [anthony.ding]
  team: computer-capabilities
  source_workflow: brand-inspiration
---
# Brand Inspiration

Analyze competitor websites and build a visual reference deck with strategic annotations.

## Phase 1: Competitor Discovery

1. Parse the brand context and product category.
2. Search for top competitors and best-in-class brands in the category.
3. Identify 6-10 competitor websites to analyze.
4. If the user provided their own URL, fetch it first to understand their current brand.

## Phase 2: Website Analysis (spawn parallel subagents)

For each competitor website:
1. Use browser_task to visit and capture screenshots of:
   - Homepage (above the fold and full page)
   - Key landing pages
   - Product pages
   - About/story page
2. Analyze and annotate for selected focus areas:
   - Copy patterns: headlines, subheadlines, value propositions, tone of voice
   - Visual design: color palette, typography, imagery style, whitespace usage
   - CTAs: placement, copy, design, urgency tactics
   - Social proof: testimonials, logos, stats, case studies
   - Navigation: menu structure, user flow, information hierarchy
   - Brand identity: logo treatment, brand story, visual consistency

## Phase 3: Reference Deck

Compile findings into a structured inspiration document:
1. Category overview and market positioning landscape
2. Per-competitor analysis with screenshots and annotations
3. Pattern analysis: common themes across top performers
4. Copy swipe file: best headlines, CTAs, and messaging examples
5. Design patterns: recurring visual approaches that work
6. Actionable recommendations for the user's brand

Share as: brand-inspiration_{category_slug}_{date}.md
