---
name: essay-revision
description: "Revise student essays and discussion posts against the instructor's stated requirements while preserving the writer's voice: check topic, length, formatting, structure, quotations, and citations; make only corrections needed for accuracy, clarity, grammar, or a direct assignment requirement. Use when the user asks to revise, review, check, or format an essay, discussion post, or assignment draft. Not for writing new essays from scratch or generic style polishing."
---

# Essay Revision

## When to Use This Skill

Run this when the user shares an essay, discussion post, or assignment draft (with or without the assignment sheet) and asks for revision, checking, or formatting. The writer's own draft is the baseline — this is preservation editing, not rewriting.

## Binding Rules

- **Minimum-change editing.** Retain the writer's argument, organization, and natural wording. Substantive changes are tied to accuracy, clarity, grammar, or a stated assignment requirement — nothing else.
- **The prompt governs.** Do not assume a citation style, source, or requirement the course materials did not establish.
- **Verify quotations.** Quoted material must match the source and attribution must match the citation; if a source cannot be verified, flag it rather than fixing it silently.

## Workflow

1. **READ THE REQUIREMENTS FIRST** — Before touching the draft, list the assignment's distinct requirements: topic, minimum length, required concepts or readings, structure, formatting, and separate deliverables (e.g., an initial post plus a separate reply to a classmate).
2. **CHECK COVERAGE** — Compare the draft against each requirement. Separate what is covered from what still needs source verification.
3. **REVISE** — Make targeted corrections only where needed for accuracy, clarity, grammar, or assignment fit. Keep the writer's voice.
4. **VERIFY QUOTES AND CLAIMS** — Check quoted material and attribution against sources; flag unsupported claims and places where the draft may conflict with the assignment.
5. **REPORT** — Explain what was changed, what still needs checking, and whether the draft appears to satisfy the assignment requirements. If the user asks for a file-ready version, present clean, submission-ready text with the structure intact.

## Example

Input: "Check my discussion post against the prompt — 300 words minimum, must cite the Tim Wise reading, plus a reply to a classmate."
Output: a corrected post keeping the writer's argument and wording; a note that the citation format was not specified in the course materials and was flagged rather than assumed; a checklist showing the post meets length and source requirements; a drafted classmate-reply outline pending an actual classmate's argument.
