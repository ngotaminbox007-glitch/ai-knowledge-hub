---
name: claims-evidence-verification
description: "Organize and verify evidence for a benefits claim or case: compare statements, symptoms, dates, and exam accounts against source records, flag mismatches, and identify what is verified versus still missing. Use when the user asks to check a claim narrative against records, verify evidence for a VA claim, or review a compensation and pension exam account. Not for filing claims, drafting appeals, or analyzing benefit award letters."
---

# Claims Evidence Verification

## When to Use This Skill

Run this when the user asks to verify a claim, symptom list, or exam account against their actual records — e.g., checking whether a C&P exam write-up matches what was reported to the examiner, or whether a stated condition is documented anywhere in the file. The deliverable is a verified/unverified comparison and gap list.

## Binding Rules

- **Never guess or reconstruct.** Where a number, date, or record is missing, say what is missing and stop there.
- **An account is not evidence until the record exists.** The user's recollection of an exam or event is flagged as unverified until the written report or document is in hand.
- **Preserve the file inventory.** Keep page references and document structure intact while comparing; never reorganize records as a side effect of verification.

## Workflow

1. **BUILD THE STATEMENT LIST** — Extract every checkable assertion: conditions, symptom onset and frequency, dates, exams, treatments, and functional impacts.
2. **COMPARE AGAINST RECORDS** — Match each assertion to source documents (C&P reports, VA claims records, exam accounts). Cite the document for each match.
3. **FLAG MISMATCHES** — Where the statement and the record disagree (e.g., an exam account that omits symptoms the user reports having raised, or dates that conflict), list the discrepancy plainly.
4. **SORT VERIFIED VS MISSING** — Produce two lists: what the records support, and what still needs documentation.
5. **IDENTIFY THE NEXT RECORD** — End with the single document that would close the largest gap.

## Example

Input: "Does the written exam report match what I told the examiner about my back and knee pain at the Fremont CP exam?"
Output: a side-by-side of reported statements vs the written report; a flagged mismatch where reported bilateral knee pain does not appear in the write-up; a verified list of the conditions the report does document; a missing-items list (e.g., no treatment records attached); next action: request the complete exam report and compare page by page.
