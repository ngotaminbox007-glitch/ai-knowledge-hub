---
name: veteran-education-search
description: "Weekly search for grants, scholarships, and veteran-support programs at San Jose-area educational institutions, prioritizing flexible schedules and veteran accommodations. Use when the user asks to find education funding, veteran scholarships, college support programs, or flexible course options in San Jose. Not for California veteran housing program monitoring or for analyzing the user's own benefit documents."
---

# Veteran Education Search

## When to Use This Skill

Run this when the user asks for the weekly education-opportunity search, veteran grants or scholarships, or veteran-support programs at San Jose schools. The user is a student and veteran, so results must fit a course schedule and note veteran accommodations.

## Instructions

1. Search for grants, scholarships, and veteran-support programs at San Jose-area educational institutions. Include school-specific aid, veteran services offices, and external awards those schools publicize.
2. Prioritize programs with flexible schedules and veteran accommodations; note those traits for each result.
3. For each opportunity, record: name, provider or school, amount or benefit, eligibility basics, deadline, application requirements, and a source link.
4. Quote eligibility and deadline details from the official source page, not from memory or search snippets. If a detail cannot be confirmed, mark it as unverified rather than filling it in.
5. Present findings as a short dated report, with deadlines and closing windows flagged first.
6. Do not apply, submit, or contact schools or scholarship offices unless the user explicitly asks in this session. Searching and reporting only.

## Example

Input: "Search for new education opportunities for veterans this week."
Output: a dated list of three opportunities, each with school/provider, amount, deadline, flexible-schedule or accommodation notes, and a source link, with the nearest deadline flagged.
