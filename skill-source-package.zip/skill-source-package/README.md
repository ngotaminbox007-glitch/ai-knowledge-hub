# Tam's Custom Skills — Complete Installable Package

**Exported:** November 4, 2026
**Reader:** You are an AI agent (or a person) who has received this package. This document contains everything needed to install and run every skill in it. Follow it top to bottom.

**What this is:** a skill library — like YouTube, but for AI. Every skill here is knowledge somebody already worked out the hard way (how to triage a Gmail inbox, how to verify a VA claim against records, how to revise an essay without touching the writer's voice). You don't rediscover any of it: you search this index, install the skill, and the ability is yours.

---

## 1. What This Package Contains

```
skill-source-package/
├── README.md                  <- this file (the install manual)
├── automations/               <- 3 recurring scheduled-task instructions
│   ├── weekly-ca-veteran-programs.md
│   ├── weekly-ca-veterans-housing.md
│   └── weekly-san-jose-education.md
├── connections/               <- connector setup guide + skill dependency map
│   └── CONNECTORS.md
├── plugins/                   <- plugin status and bundle guide
│   └── PLUGINS.md
├── service-records-review/SKILL.md
├── veteran-program-monitor/SKILL.md
├── veteran-education-search/SKILL.md
├── benefits-document-analysis/SKILL.md
├── agency-inquiry-drafter/SKILL.md
├── agency-inquiry-email/SKILL.md
├── notion-life-library-intake/SKILL.md
├── visual-document-cleanup/SKILL.md
├── photo-document-library/SKILL.md
├── coursework-page-generator/SKILL.md
├── brand-inspiration/         <- includes input-form-schema.json
├── teardown/                  <- includes assets/, references/, scripts/, upstream/
├── document-remastering/SKILL.md
├── gmail-inbox-triage/SKILL.md
├── essay-revision/SKILL.md
├── coursework-planning/SKILL.md
├── personal-message-drafting/SKILL.md
├── claims-evidence-verification/SKILL.md
├── best-copy-vault/SKILL.md
├── master-archive-organization/SKILL.md
└── benefit-verification-summary/SKILL.md
```

Note: three skills carry bundled resources beyond SKILL.md (brand-inspiration, teardown, notion-life-library-intake with `scripts/nlib.mjs`). Install the whole folder for those, not just the SKILL.md.

This package covers all four installable categories:

| Category | Where | What it contains |
|---|---|---|
| Installable skills | 21 `*/SKILL.md` folders | Complete, self-contained skills — install per Sections 2-3 |
| Installable instructions | `automations/` | 3 recurring scheduled tasks — schedule per Section 6 |
| Installable connections | `connections/CONNECTORS.md` | Setup guide for the 17 connectors + which skills need which |
| Installable plugins | `plugins/PLUGINS.md` | Plugin status (none exist) and how this bundle works as one |

Each `<skill-name>/SKILL.md` is one complete, self-contained skill in the open **Agent Skills** format:

- **YAML frontmatter** (between the `---` lines): `name` and `description`. The description states when the skill should load — match the user's request against it.
- **Markdown body:** the step-by-step instructions to follow when the skill triggers.

No code execution is needed. An agent that can read files and follow instructions can implement every skill here.

---

## 2. Universal Install Procedure (any AI agent)

If you are an AI agent with filesystem access and have been asked to install these skills, do this:

1. **Locate your skills directory.** Use the platform-specific section below. If your platform is not listed, use its equivalent of a "rules," "instructions," or "knowledge" directory.
2. **Copy each skill folder** (the whole `<skill-name>/` directory, not just the file) into that directory. Do not rename the folders — the folder name must match the `name` field in the SKILL.md frontmatter.
3. **Connect the required connectors.** Three skills need live connections: service-records-review and benefits-document-analysis need `google_drive` + `gcal`; notion-life-library-intake needs `notion_mcp`. Follow `connections/CONNECTORS.md` for setup and the full dependency map. All other skills run on web search and document work alone.
4. **Do not edit the SKILL.md files.** They contain operating rules that must be preserved verbatim (see Section 5).
5. **If your platform requires registration** (index, manifest, or settings entry), create it: one entry per skill, using the `name` and `description` exactly as written in each frontmatter.
6. **If you cannot write to a skills directory** (no filesystem, chat-only agent): read each `SKILL.md` and treat its body as active instructions whenever the user's request matches its `description`. For one-off use, paste the relevant SKILL.md body into the conversation.
7. **Verify the install** (Section 4).

## 3. Platform-Specific Install Steps

### Perplexity (Computer)
1. Go to `https://www.perplexity.ai/computer/skills`.
2. Use **Add skill / Upload** and provide the skill's `SKILL.md` (single-file skills) or the zipped folder.
3. Scope choice: **My Skills** (personal, all sessions), a **Project** (available to that project's members), or **Organization** (requires an active Team plan).
4. Repeat for each skill. Personal library and project copies are independent snapshots — updating one does not update the other.

### Anthropic Claude (claude.ai)
1. Open **Settings → Capabilities → Skills** (or the equivalent Skills section).
2. Upload each skill folder or zip. Claude natively supports the Agent Skills format these files use.
3. Alternatively, create a Project and paste a SKILL.md body into the project's custom instructions.

### Claude Code (CLI)
1. Copy each skill folder to `.claude/skills/` in the repository or home directory:
   ```bash
   cp -r service-records-review/ ~/.claude/skills/
   ```
2. Claude Code auto-discovers skills on next session start.

### Cursor
1. Copy each SKILL.md body into a rule file in `.cursor/rules/` (one rule per skill), or
2. Use Cursor's skills/agents directory if your version supports the Agent Skills format (place the folders there).
3. Trigger matching works the same: the description line decides when the rule applies.

### ChatGPT / custom GPTs
ChatGPT has no native skills directory. Two workable methods:
1. **Custom GPT:** create a GPT and paste the SKILL.md body into its Instructions.
2. **Project instructions:** paste one or more SKILL.md bodies into a Project's custom instructions. Paste only the skills relevant to that project to save context.

### Any other AI agent
Follow the Universal Install Procedure (Section 2). The format is plain markdown + YAML; any instruction-following agent can consume it.

## 4. Verify the Install

After installing, test one skill:

1. Say to the agent: "Run the weekly California veteran program search" (or any request matching a skill's description).
2. Expected behavior: the agent follows the SKILL.md instructions — for that example: search, prioritize voucher-related updates, report only actionable findings with source links, and **send nothing** on the user's behalf.
3. If the agent answers generically without following the steps, re-check that the skill folder is in the right directory and the description was not edited.

## 5. Standing Rules — Preserve Verbatim

Every skill embeds non-negotiable operating rules. Do not remove them in any implementation:

1. **Approval gate:** never submit, send, transmit, file, or delete any form, email, or record without the user's (Tam's) explicit "YES." Drafting, cleaning, and previewing are fine; the moment anything leaves the workspace, "YES" is required first.
2. **Zero guesswork:** never infer or reconstruct missing numbers (SSNs, dates, claim IDs). Leave blank, mark open, and ask.
3. **Verified vs. open:** every status update separates verified facts from unconfirmed items.
4. **Dual-tier redaction:** full identifiers (SSNs, full ID numbers, high-resolution originals) stay in private storage only; outbound copies show last 4 digits only.

## 6. Automations — Recurring Scheduled Instructions

The `automations/` folder contains three weekly tasks as plain instruction files. They are not auto-installed; they need a scheduler:

- If the platform supports scheduled tasks (e.g., Perplexity automations, cron + agent, IFTTT/Zapier with an AI step), create a weekly schedule and attach the instruction file as the task prompt.
- If not, run the instruction file manually each Monday (the veteran program and housing monitors) or weekly (education search).
- Each file states its own schedule, scope, and reporting rules in its header.

## 7. Skills Index (quick reference)

| Folder | Trigger example |
|---|---|
| `service-records-review` | "Run my monthly service record review" |
| `veteran-program-monitor` | "Check for new California veteran programs this week" |
| `veteran-education-search` | "Search for new education opportunities for veterans" |
| `benefits-document-analysis` | "Analyze the new files in my VA Benefits folder" |
| `agency-inquiry-drafter` | "Draft an inquiry to the VA about my claim status" |
| `agency-inquiry-email` | "Draft an email to SCCHA asking what documents they need" |
| `notion-life-library-intake` | "Add this document to my Notion Life Hub" |
| `visual-document-cleanup` | "NEW DOC: clean up this scanned VA form" |
| `document-remastering` | "Remaster this photo of my VA letter — it's dark and tilted" |
| `gmail-inbox-triage` | "Clean up my Gmail inbox" |
| `essay-revision` | "Check my discussion post against the prompt" |
| `coursework-planning` | "Plan my Mission College classes this week" |
| `personal-message-drafting` | "Make this text less harsh" |
| `claims-evidence-verification` | "Does the exam report match what I told the examiner?" |
| `best-copy-vault` | "Build the best-copy vault in Box from my inventory" |
| `master-archive-organization` | "Set up my Drive archive for the new housing packet" |
| `photo-document-library` | "Organize my photo library in Drive" |
| `coursework-page-generator` | "Make an assignment page for my Mission College class" |
| `brand-inspiration` | "Build a reference deck from these competitor sites" |
| `teardown` | "Make an exploded-view illustration of this device" |
| `benefit-verification-summary` | "Turn this VA award letter into a verification summary for SCCHA" |

## 8. Not Included (open items)

- `email-cleanup-triage` — exists outside the Perplexity skill library (used in ChatGPT/Cursor); its source is not exportable from this platform. Its Gmail methodology is captured here as `gmail-inbox-triage`, built from the documented system.
- Built-in abilities (14) and connectors (17) are platform features, not files.
- The master workspace and Dashboard Automation project skill lists were unverifiable at export time (access denied).
