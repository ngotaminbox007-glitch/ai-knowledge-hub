# Connections — Installable Setup Guide

**Reader:** You are an AI agent or a person setting up Tam's environment. This file lists every connection (connector) the skills and automations in this package rely on, what each unlocks, and how to connect it. Follow it when installing the package or when a skill reports a missing connection.

## How Connections Work

Connectors are account-level integrations between the AI platform and an external service (Google Drive, Notion, Dropbox, etc.). They are authorized once per account — no per-skill setup. After a connector is authorized, any skill or automation that references it can use it. Skills that need a connector declare it in their SKILL.md frontmatter under `metadata.perplexity.connectors`; treat that list as the source of truth for dependencies.

## Connector Setup Steps (Perplexity)

1. Open the platform settings (web app → Settings → Connectors / Apps).
2. Find the service in the list and choose Connect.
3. Authorize in the service's consent screen (opens a browser login for that service).
4. Return to the platform; the connector shows as connected.
5. Test with the verification task in the skill that needs it.

## The 17 Connections

| Connector | What it unlocks | Needed by |
|---|---|---|
| google_drive | Read and analyze Google Drive content (benefit documents, trackers, records inventory) | service-records-review, benefits-document-analysis, photo-document-library (usage) |
| gcal | Gmail search plus Google Calendar create/search — Gmail is reached through this connector | service-records-review, benefits-document-analysis |
| notion_mcp | Search and create Notion content (Life Hub tables, trackers) | notion-life-library-intake |
| dropbox_mcp | Search, read, manage Dropbox files and shared links | photo-document-library (usage) |
| box | Read and search Box content; `box` CLI available in sandbox | photo-document-library (usage) |
| canva | Create/edit designs, search design history, brand workflows | brand-inspiration (usage) |
| github_mcp_direct | Search and manage GitHub repositories; `gh` and `git` CLIs | general development work |
| google_photos__pipedream | Google Photos library | photo/document library work |
| google_tasks__pipedream | Google Tasks sync across devices | task tracking work |
| spotify__pipedream | Spotify library | personal use |
| outlook | Search emails and calendar events | email triage work |
| sportradar | Live sports scores, schedules, standings | personal use |
| opticodds | Real-time sports odds and betting data | personal use |
| polymarket | Public Polymarket market data (no account needed) | research |
| finance | Institutional-grade market data | research |
| health | Health-related data | research |
| gws (Google Drive CLI) | Command-line access to Google Drive in the sandbox | bulk Drive file operations |

## Dependency Map — Skills to Connections

| Skill | Required connectors | Fails without |
|---|---|---|
| service-records-review | google_drive, gcal | Cannot read Drive records or Gmail replies |
| benefits-document-analysis | google_drive, gcal | Cannot read VA Benefits/SCCHA folders or benefit emails |
| notion-life-library-intake | notion_mcp | Cannot file into Notion Life Hub |
| veteran-program-monitor, veteran-education-search, agency-inquiry-drafter, agency-inquiry-email, coursework-page-generator, teardown, benefit-verification-summary, visual-document-cleanup, brand-inspiration | None (web search / document work only) | — |

## Verification

After connecting, verify each critical path:

1. **google_drive + gcal:** ask "What files are in my VA Benefits folder?" — a successful listing means both are connected and the benefits-document-analysis skill is runnable.
2. **notion_mcp:** ask "Find my Document Library page in Notion" — a successful search means notion-life-library-intake is runnable.
3. If a connector is missing, the platform will report it when the skill runs; connect it and re-run. Never bypass a denied connection through another tool or credential.
