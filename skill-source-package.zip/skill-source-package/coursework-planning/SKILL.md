---
name: coursework-planning
description: "Plan coursework across multiple classes: combine assignments by class and due date, prioritize by deadline, weight, estimated effort, and stated priorities, and break large tasks into steps. Use when the user asks to plan their semester, build a coursework overview or deadline list, or coordinate assignments across classes. Not for revising essay text."
---

# Multi-Class Coursework Planning

## When to Use This Skill

Run this when the user asks for a semester or week plan, an assignment overview, or a deadline list spanning more than one class. The output is a prioritized working plan, not edited coursework.

## Binding Rules

- **Keep each class distinct.** Do not carry one instructor's rules, readings, or formats into another class. Each class has its own materials and requirements.
- **Separate confirmed dates from tentative plans.** If a due date is not stated, mark it tentative and ask — never invent a deadline.
- **Leave room for revision.** Plans must account for assignment revisions and late work, not just first drafts.

## Workflow

1. **GATHER** — For each class, list active assignments with due dates, lengths, formats, and any instructor notes (e.g., which week's response is due, whether a reply to a classmate is a separate deliverable).
2. **ORDER** — Sort by deadline; where deadlines collide or near each other, weigh by stated importance and estimated effort (how many days of work each item realistically needs).
3. **BREAK DOWN** — For large assignments (papers, exams), list concrete steps: outline, draft, revision, final review, submission.
4. **BALANCE** — Fit steps against the user's available work time, protecting the nearest deadline first and staggering effort so one class does not crowd out another.
5. **REPORT** — Deliver the plan as a clear overview (per class and per deadline), flag tentative items, and end with the single next action.

## Example

Input: "Give me a plan for my Mission College classes this week."
Output: a per-class list of active assignments sorted by due date; HIST 17A chapter response prioritized first because it is due earliest and needs a chapter read plus a 200-400 word response; the ENGL C1000 discussion post and classmate reply scheduled after with a drafted revision window; tentative dates flagged for anything the syllabus did not confirm; next action: read the assigned HIST chapter today.
