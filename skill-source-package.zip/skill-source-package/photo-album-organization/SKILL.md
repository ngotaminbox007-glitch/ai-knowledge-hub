---
name: photo-album-organization
description: "Organize a photo library or Google Takeout archive where photos are really documents in disguise: one best copy per document in a category folder tree, contact-sheet labeling in batches, duplicates archived not deleted, and a vault plus Box backup for VIP documents. Use when the user asks to organize their photo album, process the next Takeout batch, continue the Photos by Category library, or file photos by document type. Not for single-document cleanup or email triage."
metadata:
  version: '1.0'
  author: 'Built from Tam Ngo''s photo album organization sessions, Nov 2026'
  perplexity:
    connectors:
      - id: google_drive
        reason: The category library lives in Drive; batch extraction and uploads run through the gws CLI or Drive connector.
      - id: box
        reason: VIP documents get a Box backup copy.
---

# Photo Album Organization

## The Idea in One Sentence

Every photo is a document in disguise — a screenshot of a pay stub is a pay stub. Each one gets exactly one correct, labeled home, so anyone can find "Tyler's SS card" or "the 2024 tax return" in seconds instead of scrolling 29,000 chronological photos.

## The Rules (Never Broken)

1. **Approval gate**: nothing is deleted, sent, shared, or submitted without the user's explicit "YES."
2. **Archive, never delete**: duplicates and bad copies go to the Review folder.
3. **One best copy** per document lives in its category. All other copies go to Review as `DUP —`.
4. **One exact location per file.** No file lives in two category folders.
5. **Content decides the category, never the filename.** Every image is opened and read.
6. **Person-first names**: the person's name is read from the document itself.
7. **Originals stay untouched**: the Takeout ZIPs and Google Photos/iCloud masters are never changed.
8. **Real photos are separate** from memes, TikTok saves, and social screenshots.
9. **Zero guesswork**: if a name, number, or date can't be read, the file starts with `OPEN —`.
10. **Sensitive data: last-4 only** (e.g. `•2054`). Never full SSNs, card numbers, CVVs, passwords, or seed phrases.
11. **Front/back pairing**: card fronts and backs are matched by capture time and kept together.
12. **VIP documents** get a vault copy plus a backup copy (Box).

## Classification Table

| Type | What it means | Where it goes |
|---|---|---|
| Best copy (keeper) | The single clearest copy of each document. Physical photo beats app screenshot; higher resolution beats lower; front and back both kept | Its category folder |
| VIP best copy | Irreplaceable documents: DD-214, military/school transcripts, birth certificates, citizenship/naturalization, VA award letters, SCCHA packet, IDs | VIP Best Copies (vault) + Box backup |
| Real photos | Genuine photos and videos of people, places, events (HEIC, MOV, MP4) | Real Photos & Memories, by year |
| Duplicate | Same document again, crops, repeat screenshots | Review, named `DUP —` |
| No-value screenshot | Lock screens, home screens, app menus, file lists, ads | Review, named `ARCHIVE —` |
| Unknown | Can't confirm person, number, or date | Category root, named `OPEN —` |

## Folder Tree

```
Photos by Category/
├── 🪪 IDs & Licenses/        (CA, AZ, LA, VA & Veteran IDs, family IDs)
├── 🛂 Passports/             (<person>, Applications & Forms)
├── 🟦 Social Security Card/  (<person>)
├── 💳 Credit & Debit Cards/  (<person>; OPEN cards at root)
├── 🏦 Bank & Finance/        (Tax Returns & Filings, W-2s & Wage Statements, 1099s & Gig Income, IRS Transcripts & Notices, Paystubs, Checks & Check Images)
├── 🔐 Logins & Credentials/  (private; service name only, never the password)
├── 📸 Real Photos & Memories/ (by year: 2024, 2025, …)
├── 🎭 Memes & Social Saves/
├── 🧾 Receipts/
├── 🎓 School & Academics/
├── 🏥 Medical & VA/
├── 🚗 Vehicle & Auto/
├── 🏠 Housing/
├── 🏛️ Government Benefits/
├── 💼 Career & Work/
├── 👨‍👩‍👧 Family/
├── 🗳️ VA Generated/          (AI-drafted letters never sent to VA)
├── ♻️ Bad Copies & Duplicates — Review/  (staging; never deleted without YES)
└── 🏛️ VIP Best Copies (vault)/  (VA Benefits, SCCHA, Service Records, IDs & Certificates)
```

The full folder key → Google Drive ID map and the household roster used for names live in `references/folder-map.md` in this skill.

## How to Rename

Pattern: `Person — Document type, key detail •last4 (front/back) (original-name).ext`

| Kind | Example |
|---|---|
| Keeper | `Tam T Ngo — AZ DL •7322 (front, exp 2033) (IMG_1234).jpg` |
| Household | `Tam & Lisa — 2022 Tax Return (IMG_0456).pdf` |
| Paystub | `Tam T Ngo — KAAVE Electric timesheet, week of Sep 21 2026 (IMG_0612).png` |
| Unverified | `OPEN — Bread Credit •5655 — Ly Huynh (verify: Mom or Ly'on) (IMG_0777).jpg` |
| Duplicate | `DUP — First Tech Debit •3580 (screenshot of same card) (IMG_0800).png` |
| No value | `ARCHIVE — Lock screen notification (IMG_6435).png` |

The original filename stays in parentheses at the end, so every file can be traced back to the ZIP.

## The Step-by-Step Process

Requirements: Python 3, ImageMagick (`magick`, `montage`), and the `gws` Google Drive CLI. Replace the batch number (`raw7`, `/tmp/b7`, `sheets7`) with the batch being run. Scripts are bundled in `scripts/`.

1. **Extract 500 files at a time** from the Takeout ZIP straight from Drive (no full download) — `extract_batch.py` (uses `rzip.py` to read the remote ZIP over HTTP range requests).
2. **Fast lane**: real photos and videos (HEIC, MOV, MP4) upload straight to Real Photos by year — `fastlane.py`.
3. **Convert** every other image to a small JPG for reading (16 at a time, ImageMagick).
4. **Build contact sheets**: 12 images per sheet, each numbered — `make_sheets.py`.
5. **Read every sheet** and write one label line per image: `N|FOLDER|Label` (see label format below).
6. **Pick one keeper per document**; everything else becomes `DUP —` or `ARCHIVE —` in Review.
7. **Upload** with `upload_batch.py`: it creates subfolders, renames, skips anything already there, retries failures. Rerun until `to upload 0`.
8. **Verify counts, list OPEN items**, and wait for the user's YES before any deletion.

## Label File Format

One line per image, in `/tmp/bNlabels.txt`:

```
289|MEDVA|Tam T Ngo — VA appointments list (Oct 2026)
368|BANK|Tam T Ngo — First Tech loan, income documents sent (Sep 28 2026)
293|REVIEW|DUP — Canvas grades/assignments screen
411|REVIEW|ARCHIVE — Lock screen notification
```

A key like `BANK/Paystubs` means the Paystubs subfolder inside Bank & Finance (created if missing).

## Failure and Remedy

- A person's name is ambiguous between two household members (e.g. a card that says "LY HUYNH" could be two people): file it `OPEN — … (verify: Mom or Ly'on)`; never pick one.
- An upload keeps failing (large videos): leave it, list it in the report as not uploaded, and continue.
- Deletion is requested mid-run: still require the explicit "YES" before anything is destroyed.

## Reporting

End every run with: files processed, keeper count, DUP/ARCHIVE counts to Review, OPEN items needing the user's decision, anything not uploaded, and one immediate next step.
