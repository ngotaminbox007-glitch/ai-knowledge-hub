# Folder Map — Keys, Folders, and Drive IDs

Folder keys used in label files (`N|KEY|Label`). IDs are Tam's "Photos by Category" Google Drive library.

| Key | Folder | Drive ID |
|---|---|---|
| REAL | 📸 Real Photos & Memories | 1-4gLXPEBB8kyQJ9uB6beL8kuYE7yzdvq |
| CAREER | 💼 Career & Work | 1JmC9IFZTWmJ53XS-YF1wy4MbxrxhPOEN |
| REVIEW | ♻️ Review | 1HJ8mc1A5gtO9IweELY4luxhCZYt9x8ps |
| BANK | 🏦 Bank & Finance | 1PW84osVpL2xyMj3A68T8Yn9sjWq0NwXD |
| LOGINS | 🔐 Logins & Credentials | 1FHkHeLcL20OpwkURbz_YOMkhTcoF4RXH |
| RECEIPTS | 🧾 Receipts | 1t85Qds1k5gfGrNIlRXX2LESOovQKtyL7 |
| CARDS | 💳 Credit & Debit Cards | 19QM3r2M2AKzrUj_cMkVYMIuyWK4y_LL3 |
| VEHICLE | 🚗 Vehicle & Auto | 1MDJbv51j-46o7xGyhatafa6tDwrNt_v- |
| HOUSING | 🏠 Housing | 1GY-jkMJ9IBsmHjtmHrJOPCvuQ25ZrzEX |
| GOVBEN | 🏛️ Government Benefits | 14SARt1cB1xp9NVOiWcraD5rj5WnFvej5 |
| SCHOOL | 🎓 School & Academics | 1OPwTk9gZ2k_g1ew_iLQ_TZD2POJwiujo |
| MEDVA | 🏥 Medical & VA | 1WLjDEh8FdpTp4yrup7q5UfAEpDehcleq |
| FAMILY | 👨‍👩‍👧 Family | 1wXyl8qKu3xj3gjq48ZUgfs2AFZoeuaa9 |
| FUN | 🎭 Memes & Social Saves | 1s2Kuw_NMcclGuuiDGu3BtBJZIZLkyNyW |
| IDS | 🪪 IDs & Licenses | 1E9DqOWYcrcrUci3MPLdCFs7AmwTQRFhU |
| (vault) | 🏛️ VIP Best Copies | 1b_qdANDsy2r_-U6jLYkY7Y59h-hGVnyl |

A key like `BANK/Paystubs` means the Paystubs subfolder inside Bank & Finance (created if missing).

## Household Roster (names used for filing)

Tam T Ngo; Lisa Thi Nguyen (spouse); Lauren Ngo; Tyler Thanh Ngo; Cathy Nguyen; Ly Tuyet Huynh (Mom); Ut Thi Nguyen; Dung Nguyen; Ly'on Huynh; Tuu Thanh Huynh; Pham family (OPEN until confirmed).

If a card says "LY HUYNH" and it could be two people, it is filed `OPEN — … (verify: Mom or Ly'on)`.
