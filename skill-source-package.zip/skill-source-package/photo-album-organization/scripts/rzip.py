#!/usr/bin/env python3
"""Open a remote ZIP on Google Drive via HTTP range requests through the gws proxy.

Transcribed from Tam Ngo's Photo Album Organization guide (Nov 2026).
Lines truncated in the PDF were completed minimally; behavior follows the guide.
Set GWS_PROXY_URL in the environment before use.
"""
import os, sys, io, subprocess, time, zipfile

PROXY = os.environ.get('GWS_PROXY_URL', '')


class BufferedHTTPFile(io.RawIOBase):
    """Seekable read-only file over HTTP Range requests, with block caching."""

    BLOCK = 4 * 1024 * 1024

    def __init__(self, url, size):
        self.url = url
        self.size = size
        self.pos = 0
        self.cache = {}  # block_idx -> bytes

    def seek(self, p, whence=0):
        if whence == 0: self.pos = p
        elif whence == 1: self.pos += p
        else: self.pos = self.size + p
        return self.pos

    def tell(self): return self.pos
    def readable(self): return True
    def seekable(self): return True

    def _fetch(self, start, end):
        for attempt in range(4):
            try:
                r = subprocess.run(
                    ['curl', '-sS', '--max-time', '300', '-x', PROXY,
                     '-H', f'Range: bytes={start}-{end}',
                     '-w', '\n%{http_code}', self.url],
                    capture_output=True, timeout=330)
                out = r.stdout
                code = out.rsplit(b'\n', 1)[-1].decode()
                body = out.rsplit(b'\n', 1)[0]
                if code in ('206', '200') and body:
                    if code == '206':
                        return body
                    # full-content response: slice it
                    return body[start:end + 1]
                if attempt == 3:
                    raise RuntimeError(f'HTTP {code} for range {start}-{end}')
            except subprocess.TimeoutExpired:
                if attempt == 3:
                    raise
                time.sleep(2 * (attempt + 1))
        raise RuntimeError(f'fetch failed for range {start}-{end}')

    def _block(self, idx):
        if idx not in self.cache:
            start = idx * self.BLOCK
            end = min(start + self.BLOCK, self.size) - 1
            self.cache.clear()  # keep only a few blocks
            self.cache[idx] = self._fetch(start, end)
        return self.cache[idx]

    def read(self, n=-1):
        if n is None or n < 0: n = self.size - self.pos
        out = bytearray()
        while n > 0 and self.pos < self.size:
            idx = self.pos // self.BLOCK
            blk = self._block(idx)
            off = self.pos % self.BLOCK
            take = min(n, len(blk) - off, self.size - self.pos)
            out += blk[off:off + take]
            self.pos += take
            n -= take
        return bytes(out)


def open_remote_zip(file_id, size):
    url = f'https://www.googleapis.com/drive/v3/files/{file_id}?alt=media'
    f = BufferedHTTPFile(url, size)
    return zipfile.ZipFile(f)


if __name__ == '__main__':
    file_id, size = sys.argv[1], int(sys.argv[2])
    z = open_remote_zip(file_id, size)
    names = z.namelist()
    print(f'members: {len(names)}')
    zinfo = z.infolist()
    # top-level structure
    from collections import Counter
    top = Counter()
    ext = Counter()
    total_uncompressed = 0
    for i in zinfo:
        parts = i.filename.split('/')
        top[parts[1] if len(parts) > 1 else parts[0]] += 1
        ext['.'.join(i.filename.rsplit('.', 2)[-2:]) if '.' in i.filename else '(none)'] += 1
        total_uncompressed += i.file_size
    print('total uncompressed GB:', round(total_uncompressed / 1e9, 1))
    print('--- top-level folders ---')
    for k, v in top.most_common(30): print(f'  {k}: {v} files')
    print('--- extensions ---')
    for k, v in ext.most_common(25): print(f'  {k}: {v}')
