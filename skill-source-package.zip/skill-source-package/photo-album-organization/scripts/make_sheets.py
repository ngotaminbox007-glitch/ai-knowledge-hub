#!/usr/bin/env python3
"""Build contact sheets: 12 numbered images per sheet, 4x3 tiles.

Reads the batch file list from /tmp/bN.txt, small JPGs from viewN/,
writes sheets to sheetsN/. Shown for batch 7 — change N.

Transcribed from Tam Ngo's Photo Album Organization guide (Nov 2026).
Lines truncated in the PDF were completed minimally; behavior follows the guide.
"""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor

N = '7'  # batch number
L = [l.strip() for l in open(f'/tmp/b{N}.txt') if l.strip()]
os.makedirs(f'view{N}', exist_ok=True)
os.makedirs(f'sheets{N}', exist_ok=True)
jobs = []
for i in range(0, len(L), 12):
    cmd = ['montage']
    for j, f in enumerate(L[i:i + 12]):
        stem = os.path.splitext(f)[0]
        p = f'view{N}/{stem}.jpg'
        cmd += ['-label', f'{i + j + 1}: {stem}', p if os.path.exists(p) else 'xc:white']
    cmd += ['-tile', '4x3', '-geometry', '420x820>+5+5', '-pointsize', '22',
           f'sheets{N}/sheet{i // 12 + 1:04d}.jpg']
    jobs.append(cmd)
list(ThreadPoolExecutor(8).map(subprocess.run, jobs))
print(len(jobs), 'sheets')
