#!/bin/sh
# Convert batch images to small readable JPGs (16 in parallel) — shown for batch 7.
# Transcribed from Tam Ngo's Photo Album Organization guide (Nov 2026);
# the resize line truncated in the PDF was completed minimally.

# list non-video images for this batch, sorted (line N = image N)
ls raw7 | grep -viE '\.(heic|mov|mp4)$' | sort > /tmp/b7.txt
mkdir -p view7 sheets7

# convert to small JPGs, 16 in parallel
cat /tmp/b7.txt | xargs -P 16 -I{} sh -c \
  'f="{}"; magick "raw7/$f[0]" -resize "1200x1600>" -quality 82 "view7/${f%.*}.jpg"'

# then run make_sheets.py to build numbered contact sheets
