#!/usr/bin/env python3
"""Extract a batch of photos from the remote Takeout ZIP to a local folder.

Transcribed from Tam Ngo's Photo Album Organization guide (Nov 2026).
Usage: python3 extract_batch.py <file_id> <size> <out_dir> <limit> [offset]
Example: python3 extract_batch.py 1weHq_ipdWRqin2cavHekcSDIDynPWky9 29693227963 raw8 500 2660
"""
import sys, os, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rzip import open_remote_zip


def main(file_id, size, out_dir, limit, skip_json=True, offset=0):
    os.makedirs(out_dir, exist_ok=True)
    z = open_remote_zip(file_id, size)
    media = [i for i in z.infolist()
             if not i.is_dir()
             and (not skip_json or not i.filename.endswith('.json'))]
    print(f'media members: {len(media)} (skipping first {offset})')
    done = 0
    for info in media[offset:offset + limit]:
        target = os.path.join(out_dir, os.path.basename(info.filename))
        if os.path.exists(target) and os.path.getsize(target) == info.file_size:
            done += 1
            continue
        with z.open(info) as src, open(target, 'wb') as dst:
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                dst.write(chunk)
        done += 1
        print(f'  [{done}/{limit}] {os.path.basename(info.filename)} ({round(info.file_size / 1e6, 1)} MB)')
    print(f'extracted {done} files to {out_dir}')


if __name__ == '__main__':
    file_id, size, out_dir, limit = sys.argv[1], int(sys.argv[2]), sys.argv[3], int(sys.argv[4])
    offset = int(sys.argv[5]) if len(sys.argv) > 5 else 0
    main(file_id, size, out_dir, limit, offset=offset)
