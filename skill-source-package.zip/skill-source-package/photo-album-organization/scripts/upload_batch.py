#!/usr/bin/env python3
"""Upload a labeled batch: rename each file per its label, file it in the
matching category folder (creating subfolders), skip what is already there,
retry failures. Rerun until 'to upload 0'. Shown for batch 7 — change N.

Inputs: /tmp/bN.txt (batch file list), rawN/ (originals),
/tmp/bNlabels.txt (label lines: N|KEY|Label).

Transcribed from Tam Ngo's Photo Album Organization guide (Nov 2026).
Lines truncated in the PDF were completed minimally; behavior follows the guide.
"""
import os, json, subprocess, time
from concurrent.futures import ThreadPoolExecutor

N = '7'  # batch number

F = {
    'REAL': '1-4gLXPEBB8kyQJ9uB6beL8kuYE7yzdvq',
    'CAREER': '1JmC9IFZTWmJ53XS-YF1wy4MbxrxhPOEN',
    'REVIEW': '1HJ8mc1A5gtO9IweELY4luxhCZYt9x8ps',
    'BANK': '1PW84osVpL2xyMj3A68T8Yn9sjWq0NwXD',
    'LOGINS': '1FHkHeLcL20OpwkURbz_YOMkhTcoF4RXH',
    'RECEIPTS': '1t85Qds1k5gfGrNIlRXX2LESOovQKtyL7',
    'CARDS': '19QM3r2M2AKzrUj_cMkVYMIuyWK4y_LL3',
    'VEHICLE': '1MDJbv51j-46o7xGyhatafa6tDwrNt_v-',
    'HOUSING': '1GY-jkMJ9IBsmHjtmHrJOPCvuQ25ZrzEX',
    'GOVBEN': '14SARt1cB1xp9NVOiWcraD5rj5WnFvej5',
    'SCHOOL': '1OPwTk9gZ2k_g1ew_iLQ_TZD2POJwiujo',
    'MEDVA': '1WLjDEh8FdpTp4yrup7q5UfAEpDehcleq',
    'FAMILY': '1wXyl8qKu3xj3gjq48ZUgfs2AFZoeuaa9',
    'FUN': '1s2Kuw_NMcclGuuiDGu3BtBJZIZLkyNyW',
    'IDS': '1E9DqOWYcrcrUci3MPLdCFs7AmwTQRFhU',
    'vault': '1b_qdANDsy2r_-U6jLYkY7Y59h-hGVnyl',
}


def gws(*a):
    return subprocess.run(['gws', 'drive', 'files', *a], capture_output=True, text=True)


def find_or_create(parent, name):
    d = json.loads(gws('list', '--params', json.dumps(
        {'pageSize': 5, 'fields': 'files(id)',
         'q': f"'{parent}' in parents and name = '{name}' and mimeType = 'application/vnd.google-apps.folder'"})).stdout)
    if d.get('files'): return d['files'][0]['id']
    return json.loads(gws('create', '--json', json.dumps(
        {'name': name, 'parents': [parent], 'mimeType': 'application/vnd.google-apps.folder'})).stdout)['id']


def resolve(key):
    if '/' not in key: return F[key]
    top, sub = key.split('/', 1)
    return find_or_create(F[top], sub)


def listnames(fid):
    names = set(); tok = None
    while True:
        p = {'pageSize': 500, 'fields': 'files(name),nextPageToken', 'q': f"'{fid}' in parents"}
        if tok: p['pageToken'] = tok
        d = json.loads(gws('list', '--params', json.dumps(p)).stdout)
        if 'error' in d: raise RuntimeError(d['error'])
        names |= {f['name'] for f in d.get('files', [])}; tok = d.get('nextPageToken')
        if not tok: return names


views = [x.strip() for x in open(f'/tmp/b{N}.txt')]
raw = {os.path.splitext(f)[0]: f for f in os.listdir(f'raw{N}')}
L = [l.split('|', 2) for l in open(f'/tmp/b{N}labels.txt').read().strip().split('\n')]
fid = {k: resolve(k) for k in {x[1] for x in L}}
print({k: v for k, v in fid.items() if '/' in k}, flush=True)
jobs = []
for i, key, label in L:
    stem = views[int(i) - 1][:-4]; fn = raw[stem]; ext = os.path.splitext(fn)[1]
    jobs.append((fn, fid[key], f'{label} ({stem}){ext}'))
inv = {v: listnames(v) for v in set(fid.values())}
todo = [j for j in jobs if j[2] not in inv[j[1]]]
print('to upload', len(todo), 'of', len(jobs), flush=True)


def up(j):
    fn, p, name = j
    for a in range(4):
        r = gws('create', '--json', json.dumps({'name': name, 'parents': [p]}), '--upload', f'raw{N}/{fn}')
        if r.returncode == 0 and '"id"' in r.stdout: return True
        time.sleep(3 * (a + 1))
    print('FAIL', fn, flush=True)
    return False


with ThreadPoolExecutor(4) as ex: ok = sum(ex.map(up, todo))
print(f'BATCH{N} DONE ok={ok}/{len(todo)}')
