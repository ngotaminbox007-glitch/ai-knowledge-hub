#!/usr/bin/env python3
"""Fast lane: upload real photos and videos (HEIC, MOV, MP4) straight to
Real Photos & Memories, filed by year. Shown for batch 5 — change rawN.

Transcribed from Tam Ngo's Photo Album Organization guide (Nov 2026).
Lines truncated in the PDF were completed minimally; behavior follows the guide.
"""
import os, json, subprocess, time
from concurrent.futures import ThreadPoolExecutor

REAL = '1-4gLXPEBB8kyQJ9uB6beL8kuYE7yzdvq'


def yearfolder(y, cache={}):
    if y in cache: return cache[y]
    out = subprocess.run(
        ['gws', 'drive', 'files', 'list', '--params', json.dumps(
            {'pageSize': 5, 'fields': 'files(id)',
             'q': f"'{REAL}' in parents and name = '{y}' and mimeType = 'application/vnd.google-apps.folder'"})],
        capture_output=True, text=True)
    f = json.loads(out.stdout).get('files', [])
    fid = f[0]['id'] if f else json.loads(subprocess.run(
        ['gws', 'drive', 'files', 'create', '--json', json.dumps(
            {'name': y, 'parents': [REAL], 'mimeType': 'application/vnd.google-apps.folder'})],
        capture_output=True, text=True).stdout)['id']
    cache[y] = fid
    return fid


files = sorted(os.listdir('raw5'))
media = [f for f in files if f.rsplit('.', 1)[-1].lower() in ('heic', 'mp4', 'mov')]
jobs = []
for f in media:
    y = f[:4] if f[:4].isdigit() and f[:2] == '20' else None
    jobs.append((f, yearfolder(y) if y else REAL))
print('fast lane:', len(jobs), flush=True)


def up(j):
    f, p = j
    for a in range(4):
        r = subprocess.run(
            ['gws', 'drive', 'files', 'create', '--json', json.dumps({'name': f, 'parents': [p]}),
             '--upload', f'raw5/{f}'], capture_output=True, text=True)
        if r.returncode == 0 and '"id"' in r.stdout: return True
        time.sleep(4 * (a + 1))
    print('FAIL', f, flush=True)
    return False


with ThreadPoolExecutor(4) as ex: ok = sum(ex.map(up, jobs))
print(f'FASTLANE5 DONE ok={ok}/{len(jobs)}')
