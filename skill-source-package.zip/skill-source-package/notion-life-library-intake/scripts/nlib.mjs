import fs from 'fs';
import path from 'path';
const T = () => globalThis.tools;
export async function retry(fn, tries = 4) {
  for (let a = 0; ; a++) {
    try { return await fn(); }
    catch (e) {
      const m = String(e.message || e);
      if (a < tries && /rate.?limit|429/i.test(m)) { const w = parseInt((m.match(/(\d+) seconds/) || [])[1] || '30', 10); await new Promise(r => setTimeout(r, (w + 3) * 1000)); continue; }
      throw e;
    }
  }
}
const MIME = { pdf:'application/pdf', png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', txt:'text/plain', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', md:'text/plain', heic:'image/heic' };
export async function upload(p, filename) {
  filename = filename || path.basename(p);
  const ext = filename.split('.').pop().toLowerCase();
  const u = await retry(() => T().notion_mcp_notion_create_file_upload({ filename }));
  const r = u.result || u;
  const fd = new FormData();
  fd.append('file', new Blob([fs.readFileSync(p)], { type: MIME[ext] || 'application/octet-stream' }), filename);
  let resp, j;
  for (let a = 0; a < 4; a++) { resp = await fetch(r.upload_url, { method: 'POST', headers: r.upload_headers, body: fd }); j = await resp.json(); if (resp.status !== 429) break; await new Promise(r => setTimeout(r, 20000)); }
  if (!resp.ok) throw new Error('upload fail ' + filename + ' ' + JSON.stringify(j).slice(0, 200));
  return j.file_upload_id;
}
export const fileProp = (ids) => JSON.stringify(ids.map(id => ({ type: 'file_upload', file_upload: { id } })));
// rows: [{props:{...}, files:[{path,name}]}]
export async function addRows(dsId, rows, { concurrency = 3 } = {}) {
  const results = [];
  let i = 0;
  async function worker() {
    while (i < rows.length) {
      const k = i++;
      const row = rows[k];
      try {
        const props = { ...row.props };
        const r = await retry(() => T().notion_mcp_notion_create_pages({ parent: { data_source_id: dsId }, pages: [{ properties: props, ...(row.content ? { content: row.content } : {}) }] }));
        const pg = (r.result || r).pages?.[0];
        if (row.files && row.files.length) {
          const ids = [];
          for (const f of row.files) ids.push(await upload(f.path, f.name));
          await retry(() => T().notion_mcp_notion_update_page({ page_id: pg.id, command: 'update_properties', properties: { File: fileProp(ids) } }));
        }
        results[k] = { ok: true, id: pg?.id, name: props.Name };
      } catch (e) { results[k] = { ok: false, name: row.props.Name, err: e.message.slice(0, 200) }; }
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));
  return results;
}
export async function count(dsId) {
  const u = 'collection://' + dsId;
  const q = await T().notion_mcp_notion_query_data_sources({ data: { data_source_urls: [u], query: `SELECT COUNT(*) AS n FROM [${u}]` } });
  return (q.result?.results || q.results)?.[0]?.n;
}
export async function rows(dsId, cols = '*', extra = '') {
  const u = 'collection://' + dsId;
  const q = await T().notion_mcp_notion_query_data_sources({ data: { data_source_urls: [u], query: `SELECT ${cols} FROM [${u}] ${extra}` } });
  return q.result?.results || q.results;
}
