---
name: notion-life-library-intake
description: "File new documents into Tam's Notion Life Hub: label each file, pick the matching table, upload one best copy as a native Notion file, mark gaps MISSING, and turn email drafts into Word files. Use when Tam sends, creates, or finds a document, email, deadline, or says add this to Notion."
---

# Notion Life Library intake

Tam's standing rule: every file received, created, or found that is important and relevant gets labeled and placed in the right Notion table, so a click opens or downloads the best copy.

## Where things live (workspace "Tam T Ngo's Space")

Hub page 40b11e15-67c3-81dd-99bb-d7e0718f4e92. Document Library page 40b11e15-67c3-8166-8ff2-e48728ede636 shows all tables. Data source IDs:

| Table | Data source ID | Columns |
| --- | --- | --- |
| Identity & Household | 659d3c9c-e299-4bb8-b41e-111279448bd8 | Name, Copy, File, Notes, Person |
| VA Decision Letters | 17476884-272b-4a21-9730-4fb60a55fa86 | one row per letter, Letter #, Letter date |
| DD214 | deb84a53-bea0-4fad-8c0a-91896d4eecdb | best copy plus redacted copy |
| Military Evals | 64c3ce3c-f171-4712-8514-433907cea7f7 | evals, OMPF, JST, discharge records |
| Housing, SCCHA | b9f8c5ab-f5d4-41ba-ac4d-856e5387e367 | Section 1 to 4, Date, Status |
| Benefits, School, Financial, Legal | f49b4850-200a-447d-bfe0-ed6e6bdd2cde | Category, Person, Date |
| Email Drafts (Word) | d0c42836-1a1a-4ad1-ae1e-9b963050e356 | To, Topic, Gmail link, File |
| Reminders, Deadlines & Appointments | 95e722c4-49e5-4f2b-98f6-6ff29f87f765 (view://69b887fa-7d87-464f-8e7b-ef6dbe5ded90) | Name, Date, Type, Area, Status, Source (Gmail/Outlook/Google Calendar/Documents/Manual), Priority, Details, Where or who, Related document |
| Life Timeline | 4d76d401-f034-4cb7-9ff8-6b0dbd3cff9b | Date, Category, Outcome, Related document |

## Rules

1. One best full copy per document. Add one redacted copy only when a redacted version exists or is needed. Never upload near-duplicates or low-quality copies. Max 2 to 3 per document.
2. Driver license front and back go in one row with two files (file 1 front, file 2 back).
3. Upload the real file into the File property. Do not use Drive or Gmail links as the only access path: Tam's phone Google apps can be signed in to the wrong account and show "File not found".
4. Row format: Name, Copy tag (Best copy, Other copy, or MISSING), File, Notes written as "What it is | How to use". Flag full SSNs and bank account numbers in Notes.
5. If a requested document is not found, create the row with Copy = MISSING and no file so Tam can upload it.
6. Email drafts: always make a .docx of the draft, attach it to a row in Email Drafts, and set Gmail link to `https://mail.google.com/mail/?authuser=ngotam.inbox007@gmail.com#drafts?compose=<id>`.
7. Dated items (deadlines, appointments, school work, promises, reply-by dates, payment due dates) become rows in Reminders, Deadlines & Appointments. Check the view first so no row is duplicated; update a matching row instead of adding one. Outlook account is ngotam.inbox007@outlook.com. Decisions and events become rows in Life Timeline.
8. Select options must already exist before a row uses them. Date properties use `date:Date:start` and `date:Date:is_datetime`.

## Upload recipe

`scripts/nlib.mjs` (copy to the workspace, import in an exec cell): `upload(path, filename)` returns a file upload ID, `fileProp([ids])` builds the File property value, `addRows(dsId, [{props, files:[{path,name}]}], {concurrency:2})` creates rows and attaches files, `retry(fn)` retries 429 and 5xx errors. Keep concurrency at 2 for Notion and 4 or less for the Drive API.

## Checks

After adding rows, confirm each one has a file (or an intended MISSING tag) with a view-mode query of the table. SQL-mode queries may hit a usage limit; view-mode queries still work.
