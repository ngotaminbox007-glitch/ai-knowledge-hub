---
name: service-records-review
description: "Monthly review of the user's military service and VA records in Google Drive and Gmail: find new or changed records, VA request receipts or replies, and time-sensitive deadlines, then update only the existing Military Service Records Inventory with verified changes and a dated log entry. Use when the user asks to review service records, run the monthly records check, or update the records inventory. Not for benefits-document analysis or searching the web for new programs."
metadata:
  perplexity:
    connectors:
      - id: google_drive
        reason: Reads the user's Drive folders where service and VA records are stored and where the Military Service Records Inventory lives.
      - id: gcal
        reason: Gmail is reached through this connector; it is searched for VA request receipts and replies.
---

# Service Records Review

## When to Use This Skill

Run this when the user asks for the monthly service-record review, a records check, or an update to the Military Service Records Inventory. The user is a U.S. Navy veteran tracking VA records; submissions and agency contact remain with the user.

## Instructions

1. Open the Military Service Records Inventory and read its dated log to find the date of the last completed review.
2. Search Google Drive and Gmail for military service and VA records created or changed since that date: new or updated documents, VA request receipts, VA replies, and anything time-sensitive (deadlines, exam dates, decision windows).
3. Verify each candidate item against its source document before recording it. Do not infer dates, claim numbers, or file numbers that are not visible in the source.
4. Update only the Military Service Records Inventory: add the verified changes and append one dated log entry for this review describing what was checked and what changed.
5. Do not alter any other file, send messages, or contact agencies. Report findings in the session.
6. Separate verified findings from open items: anything unconfirmed or missing from the sources gets listed as an open item for the user to resolve, not filled in.

## Example

Input: "Run my monthly service record review."
Output: a short findings list (new VA reply received, one updated record), a note that the inventory and its dated log were updated, and any open items — for example, "reply references a form not yet in Drive — left as open."
