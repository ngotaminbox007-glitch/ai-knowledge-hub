# Automation: Weekly San Jose Veteran Education Opportunities

**Schedule:** Weekly
**Type:** Web search + report. No sending, submitting, or contacting schools on the user's behalf.

## Task Instructions

Search the web for new or currently open educational grants, scholarships, and veteran-specific support programs at San Jose, CA educational institutions (e.g., San Jose State University, San Jose City College, Evergreen Valley College, National University San Jose, and other local colleges/training programs), plus county/state programs usable there. Prioritize programs offering flexible scheduling (online, evening, hybrid, part-time) or specific accommodations for veterans (Veterans Resource Centers, GI Bill/VA certifying officials, priority registration, disability accommodations). Note anything new since the prior week's run when possible. Deliver a concise summary of the top 5-10 opportunities: name, institution, what it offers, deadline, veteran/flexibility features, a link to the eligibility page, and contact info (phone/email/office) for the relevant admissions, financial aid, or veterans services office. Cite sources with inline links. The user is a U.S. Navy veteran and student in Santa Clara, CA.
