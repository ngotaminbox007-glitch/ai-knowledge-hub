# Automation: Weekly CA Veterans Housing Updates

**Schedule:** Mondays, 8:00 AM Pacific
**Type:** Web search + report. No sending, submitting, or contacting agencies on the user's behalf.

## Task Instructions

Weekly California veteran housing and support program search for Tam Ngo (U.S. Navy veteran, Santa Clara, CA; VA rating 100% P&T; SCCHA-administered voucher with an active reasonable-accommodation request, transfer, and household-update case). Search for changes and new offerings in California veteran housing and support programs, including documentation and reasonable-accommodation requirements and county veterans service offices statewide, prioritizing Santa Clara County and nearby counties. For each program found, check and record: program name, administering agency, eligibility basics, documentation requirements, and any reasonable-accommodation provisions. Prioritize items that affect housing vouchers, transfer paperwork, household updates, or accommodation requests; list others briefly. Present findings as a short dated report with a source link for every program. Quote documentation and accommodation requirements from the official source, not from memory. Do not submit applications, contact agencies, or draft messages to them unless the user explicitly asks in the session. Flag anything with a deadline or application window so the user can decide whether to act.
