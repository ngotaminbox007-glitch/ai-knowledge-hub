---
name: best-copy-vault
description: "Build and maintain a curated best-copy vault: select the best copy of each important record from Drive or Notion inventories, place them in matching vault folders, verify uploads, and hold duplicates in review folders until approved. Use when the user asks to build a best-copy vault, copy records into Box or Drive vault folders, or verify vault coverage against an inventory. Not for photo library categorization or inbox triage."
metadata:
  perplexity:
    connectors:
      - id: box
        reason: The vault lives in Box; file search, upload, and verification run through it.
      - id: google_drive
        reason: Best copies are often sourced from Drive and compared against the Drive inventory.
      - id: notion_mcp
        reason: The Notion inventory is the cross-check for vault coverage.
---

# Best-Copy Vault

## When to Use This Skill

Run this when the user asks to build or extend a curated vault of best copies — the single best copy of each important record (IDs, VA letters, benefit documents, statements) placed in matching folders — or to verify that a vault covers the full inventory.

## Binding Rules

- **Curated, not bulk-copied.** The vault holds one best copy per record, selected from catalogued best copies — not a mirror of everything.
- **Review folders, never deletion.** Duplicates, unreadable scans, and superseded copies go to labeled review folders and are retained until the user approves disposal.
- **Private and outbound stay separate.** Private full-copy masters never sit in outbound vault folders.

## Workflow

1. **SOURCE FROM THE INVENTORY** — Use the catalogued best copies (e.g., the Notion Document Library inventory) as the candidate list. Do not hunt for new copies unless an inventory item has none.
2. **PLACE IN MATCHING FOLDERS** — Copy each best copy into the vault folder matching its category, mirroring the inventory structure.
3. **VERIFY UPLOADS** — After copying, confirm every inventory item is present in the vault; report any that failed or are missing.
4. **STAGE DUPLICATES** — Move duplicate or low-quality copies found along the way to labeled review folders for the user's decision.
5. **REPORT COVERAGE** — End with a coverage summary (in vault / missing / in review) and one immediate next step.

## Example

Input: "Build the best-copy vault in Box from my Notion inventory."
Output: best copies placed in matching Box folders per the inventory; a verification pass confirming each inventory item present; 7 duplicates moved to a labeled review folder pending the user's approval; coverage report listing 3 inventory items with no best copy yet; next action: choose replacements for the 3 missing items.
