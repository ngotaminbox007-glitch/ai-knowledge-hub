---
name: agency-inquiry-drafter
description: Draft a professional, respectful, persistent inquiry email to a government agency or office (e.g., VA, SCCHA, SSA, DMV, school registrar) when the user gives a topic or agency. Use when the user asks to draft an inquiry, request clarification, or ask an agency what documentation is required.
---

# Agency Inquiry Email Drafter

Input: a topic and/or agency name, plus any details the user shares (case number, deadline, prior contact).

## Steps
1. Identify the agency and the correct department if known. If the topic matters (e.g., deadlines, forms), briefly search the agency's official site to name the correct form/program and contact; cite only real URLs. Never invent case numbers, names, or form numbers.
2. Write the email with this structure:
   - Subject: clear and specific, e.g. "Request for Clarification – [Program/Topic] – [Case/Client ID]"
   - Greeting: "Dear [Agency/Department Name] Representative," (or named contact)
   - Identification block with placeholders: [Full Name], [Date of Birth], [Case/Client/Voucher/Claim Number], [Last 4 of SSN if required], [Mailing Address], [Phone], [Email]
   - Purpose: one or two sentences stating exactly what is requested.
   - Background: brief, factual, with [Date of prior contact] / [Reference number] placeholders.
   - Numbered questions: specific requests for information or clarification.
   - Documentation request: ask explicitly for (a) the complete list of required documents, (b) acceptable formats (original, copy, certified, electronic), (c) the specific form numbers, (d) submission method and address/portal, (e) deadlines, (f) whom to contact if something is unavailable.
   - Persistence: request written confirmation of receipt and a response by [Requested Response Date, e.g., 10 business days]; ask for a direct contact or escalation path if this office is not the right one; note that the user will follow up if no reply is received.
   - If relevant, mention reasonable accommodation needs with [Accommodation Request] placeholder.
   - Closing: "Thank you for your time and assistance." / "Respectfully," / [Full Name] / [Phone] / [Email]
3. Tone: respectful, concise, firm, non-emotional; no accusations; plain language.
4. Also provide a short follow-up email template (for no reply after the requested date) referencing the original send date.
5. Preserve the user's wording when they provide text; edit only for errors or requirements.
6. Output the draft in the chat in a copyable block. Do not send any email.
