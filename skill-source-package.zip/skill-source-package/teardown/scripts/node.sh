#!/usr/bin/env bash
# Reuse Node >=22, otherwise provision a pinned task-local runtime.
set -euo pipefail

WORK="${1:?Usage: node.sh /absolute/task/runtime}"
VERSION="22.23.4"
if command -v node >/dev/null &&
  node -e 'if (+process.versions.node.split(".")[0] < 22) process.exit(1)'; then
  command -v node
  exit 0
fi
case "$(uname -s)" in
  Linux) OS=linux ;;
  Darwin) OS=darwin ;;
  *) echo "Unsupported OS" >&2; exit 1 ;;
esac
case "$(uname -m)" in
  x86_64) ARCH=x64 ;;
  aarch64 | arm64) ARCH=arm64 ;;
  *) echo "Unsupported architecture" >&2; exit 1 ;;
esac

TARGET="$WORK/node"
if [[ -x "$TARGET/bin/node" ]] &&
  [[ "$("$TARGET/bin/node" --version)" == "v$VERSION" ]]; then
  printf '%s\n' "$TARGET/bin/node"
  exit 0
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
FILE="node-v$VERSION-$OS-$ARCH.tar.gz"
URL="https://nodejs.org/dist/v$VERSION"
curl -fsSL --retry 3 "$URL/$FILE" -o "$TMP/$FILE"
curl -fsSL --retry 3 "$URL/SHASUMS256.txt" -o "$TMP/SHASUMS256.txt"
(
  cd "$TMP"
  awk -v file="$FILE" '$2 == file' SHASUMS256.txt > expected
  [[ -s expected ]] || { echo "Missing Node checksum" >&2; exit 1; }
  if command -v sha256sum >/dev/null; then
    sha256sum -c expected >&2
  else
    shasum -a 256 -c expected >&2
  fi
)
mkdir -p "$TARGET"
tar -xzf "$TMP/$FILE" --strip-components=1 -C "$TARGET"
printf '%s\n' "$TARGET/bin/node"
