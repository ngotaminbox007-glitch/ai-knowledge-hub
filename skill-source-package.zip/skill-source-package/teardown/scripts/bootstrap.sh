#!/usr/bin/env bash
# Install pinned build dependencies only in the requested task-local runtime.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
RUNTIME="${1:?Usage: bootstrap.sh /absolute/task/runtime}"
case "$RUNTIME" in
  /*) ;;
  *) echo "Runtime directory must be an absolute task-local path" >&2; exit 1 ;;
esac
if [[ -d "$RUNTIME" ]]; then
  RUNTIME="$(cd "$RUNTIME" && pwd -P)"
else
  PARENT="$(cd "$(dirname "$RUNTIME")" && pwd -P)"
  RUNTIME="$PARENT/$(basename "$RUNTIME")"
fi
case "$RUNTIME/" in
  "$ROOT/"*) echo "Runtime directory must be outside the loaded skill" >&2; exit 1 ;;
esac
case "$ROOT/" in
  "$RUNTIME/"*) echo "Runtime directory must not contain the loaded skill" >&2; exit 1 ;;
esac
MARKER="$RUNTIME/.computer-teardown"
if [[ -e "$MARKER" || -L "$MARKER" ]]; then
  [[ -f "$MARKER" && ! -L "$MARKER" ]] || {
    echo "Invalid runtime marker; use a fresh dedicated directory" >&2; exit 1
  }
  [[ "$(< "$MARKER")" == "computer-teardown-runtime-v1" ]] || {
    echo "Unrecognized runtime; use a fresh dedicated directory" >&2; exit 1
  }
elif [[ -d "$RUNTIME" ]]; then
  shopt -s nullglob dotglob
  CONTENTS=("$RUNTIME"/*)
  [[ ${#CONTENTS[@]} -eq 0 ]] || {
    echo "Refusing to initialize an occupied runtime directory" >&2; exit 1
  }
fi
for FILE in package.json package-lock.json; do
  if [[ -e "$RUNTIME/$FILE" || -L "$RUNTIME/$FILE" ]]; then
    if [[ -L "$RUNTIME/$FILE" ]] ||
      ! cmp -s "$ROOT/assets/runtime/$FILE" "$RUNTIME/$FILE"; then
      echo "Runtime manifest differs; use a fresh dedicated directory" >&2; exit 1
    fi
  fi
done
mkdir -p "$RUNTIME"
printf '%s\n' "computer-teardown-runtime-v1" > "$MARKER"

NODE="$(bash "$ROOT/scripts/node.sh" "$RUNTIME")"
PATH="$(dirname "$NODE"):$PATH"
export PATH
cp "$ROOT/assets/runtime/package.json" "$ROOT/assets/runtime/package-lock.json" "$RUNTIME/"
npm ci --prefix "$RUNTIME" --ignore-scripts --no-audit --no-fund \
  --registry=https://registry.npmjs.org >&2
"$NODE" -e 'for (const name of ["jspdf", "svg2pdf.js", "@fontsource-variable/inter/package.json"]) require.resolve(name, {paths: [process.argv[1]]})' "$RUNTIME"
printf '%s\n' "$RUNTIME"
