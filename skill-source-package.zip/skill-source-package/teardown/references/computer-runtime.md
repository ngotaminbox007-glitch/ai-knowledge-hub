# Computer runtime

Keep the pinned skill read-only. Build in a task-local directory, not inside a repository or design-system project unless the user requested that integration.

## Setup

Set `SKILL` to the loaded skill's absolute path and `TASK` to an absolute directory in the current task workspace:

```bash
mkdir -p "$TASK"
RUNTIME=$(bash "$SKILL/scripts/bootstrap.sh" "$TASK/.teardown-runtime")
export PATH="$RUNTIME/node/bin:$PATH"
mkdir -p "$TASK/tools/teardown"
cp -R "$SKILL/upstream/assets" "$TASK/tools/teardown/"
cp -R "$SKILL/upstream/scripts" "$TASK/tools/teardown/"
cp "$SKILL/assets/helper-package.json" "$TASK/tools/teardown/package.json"
```

The bootstrap uses pinned Node.js 22.23.4 when the installed Node is older than 22, then installs the committed npm lockfile with lifecycle scripts disabled. It accepts a new or empty dedicated directory, or one carrying its own runtime marker and unchanged manifests. It refuses occupied unrelated directories, symlinked metadata, and paths inside or containing the loaded skill.

It writes only to the chosen runtime directory and prints that directory. The helper package scopes upstream's dual browser/CommonJS modules correctly, including when the surrounding project uses ES modules. Reuse it for this task; do not modify shared runtimes or copy over the user's edited viewer assets.

Set `"dependencies": ".teardown-runtime/node_modules"` in `drawing.json` when that file lives at `$TASK/drawing.json`. Relative paths resolve from the config, not from the command's working directory. This replaces the upstream package-install command. Keep model sources and outputs beside that config.

```bash
node "$TASK/tools/teardown/scripts/build-viewer.cjs" \
  "$TASK/drawing.json" "$TASK/dist/index.html"
```

The builder embeds the font, its license, PDF libraries, scripts, and styles. The resulting viewer must work without third-party network requests. Keep `upstream/LICENSE` with redistributed source and retain the embedded font license.

## Verification and delivery

Run the copied `scripts/test-*.cjs` suites. Use the available browser tools to inspect the built viewer and exercise the controls and requested exports described in the upstream verification guide. The upstream `check-viewer.cjs` is an optional standalone check when a supported Chrome executable is available; browser-tool inspection is still valid and must not be reported as that script having passed.

Before browser downloads, ensure they are within the user's requested output scope. If an export fails, fix it or state which format remains unverified. PDF is available upstream, but do not generate or deliver it unless requested.

Load the website-building skill before creating a viewer for the user. Deploy only the final output folder, not task-local dependencies, source references, credentials, or unrelated workspace files. For requested standalone files, use the file-sharing workflow instead of a local workspace link.
