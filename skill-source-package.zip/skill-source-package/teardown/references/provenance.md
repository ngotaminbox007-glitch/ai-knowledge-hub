# Teardown provenance

- Upstream author: [Jakub Krehel](https://github.com/jakubkrehel).
- Repository: [jakubkrehel/skills](https://github.com/jakubkrehel/skills).
- Pinned commit: [`592aedc44d7d5b3e29740984252902f3e5402a1c`](https://github.com/jakubkrehel/skills/commit/592aedc44d7d5b3e29740984252902f3e5402a1c).
- Original skill: [`skills/teardown`](https://github.com/jakubkrehel/skills/tree/592aedc44d7d5b3e29740984252902f3e5402a1c/skills/teardown).
- Announcement: [Teardown introduction](https://x.com/jakubkrehel/status/2114379959263502712?s=20).
- License: upstream MIT text is preserved verbatim in `../upstream/LICENSE`.

The entire upstream skill directory is vendored in `upstream/`, including its instruction hub, reference documents, geometry and viewer code, and tests. Only the hub filename changes from `SKILL.md` to `UPSTREAM.md`; all source bytes are unchanged. `upstream/SHA256SUMS` records every shipped upstream file, including the retained license, using paths relative to the package root.

The Computer adapter adds the short top-level skill hub, marketplace export metadata, this provenance record, the runtime guide, a task-local dependency bootstrap, and a Node provisioner following the existing Taste Skill adapter. Runtime dependencies are pinned with npm integrity hashes: jsPDF 4.2.1, svg2pdf.js 2.8.1, and Inter Variable 5.3.0.

The adapter replaces upstream's unpinned dependency installation, scopes copied helpers as CommonJS even inside ES-module projects, keeps loaded skill assets read-only, and routes visual verification and delivery through supported Computer workflows. It does not add paid services, automatic project installation, billing code, free-credit allowances, Eppo changes, or a live marketplace publication.
