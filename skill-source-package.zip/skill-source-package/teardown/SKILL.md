---
name: teardown
description: "Create configurable technical teardown illustrations with editable parts, colors, annotations, and SVG, PNG, or PDF exports. Use for exploded object drawings, cutaways, or technical product illustrations. Not for procurement cost analysis, infrastructure teardown, or ordinary charts."
compatibility: "Requires filesystem access, network access for task-local dependencies, and a browser for visual checks."
license: "MIT; see upstream/LICENSE"
metadata:
  author: "Jakub Krehel (jakubkrehel)"
  source: "https://github.com/jakubkrehel/skills"
  upstream-commit: "592aedc44d7d5b3e29740984252902f3e5402a1c"
  adapter-version: "1.0.0"
  perplexity:
    publisher: jakubkrehel
    display_name: Teardown
---

# Teardown

Use Jakub Krehel's pinned Teardown skill to build geometric, configurable technical illustrations. Preserve its drawing conventions, part selection, camera controls, playback, annotations, and export workflow.

## Workflow

1. Read [the complete upstream skill](upstream/UPSTREAM.md), then follow its referenced geometry, viewer, and verification guides. All relative upstream paths resolve inside `<skill-directory>/upstream/`; the snapshot is read-only.
2. Read [Computer runtime](references/computer-runtime.md) before setup. Run `bash <skill-directory>/scripts/bootstrap.sh <absolute-task-local-runtime-directory>`, copy upstream `assets/` and `scripts/` into the task workspace, and build the model and viewer from those copies. Never install into the loaded skill or run the upstream unpinned `npm install` command.
3. Ground real-object structure in the user's references or verified public material. Label inferred internals as illustrative, not an engineering drawing or dimensionally accurate reconstruction. Put explanatory caveats in contextual notes without obscuring consequential risks.
4. Run the upstream geometry and viewer-builder tests, then inspect the actual viewer in a browser. Exercise part selection and isolation, an adjustable parameter, the camera, playback, annotations, and each requested export. Check narrow and desktop layouts; do not call exports verified merely because buttons exist.
5. Deliver the requested illustration and exports. For an interactive viewer, deploy the self-contained output through the website workflow; for requested downloadable SVG, PNG, or PDF files, share those files. Do not substitute screenshots for vector exports or install this skill into the user's project.

## Source and scope

The [provenance record](references/provenance.md) identifies the upstream commit, license, and Computer-only adapter. This is an opt-in illustration skill, not a supplier-cost teardown tool. It needs no external service account, API key, paid media generation, or quota configuration.
