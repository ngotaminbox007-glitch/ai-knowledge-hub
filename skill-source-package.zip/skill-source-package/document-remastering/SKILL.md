---
name: document-remastering
description: "Visual-only remastering of document scans and photos — straightening, perspective correction, tone and shadow balancing, restrained sharpening, ink cleanup, and bounded signature merging — for a natural, unaltered look. Use when the user asks to remaster, restore, brighten, or improve the legibility of a scanned or photographed document, card, letter, or record. Not for rewriting text, drafting new documents, or aggressive artificial enhancement."
---

# Document Remastering

## When to Use This Skill

Run this when the user asks to remaster, restore, clean up, brighten, or improve a scan or photo of a document: official forms, benefit letters, IDs, cards, handwritten letters, records. The goal is a natural-looking, more legible version of what the source already shows — nothing more.

## Binding Rules

- **Visual-only operations.** Never rewrite, retype, or regenerate text; never move, resize, or redraw layout boundaries; never alter handwriting or signature strokes.
- **Natural appearance over aggressive enhancement.** Reject high-contrast, heavily sharpened results as artificial. Use balanced tone and shadow correction and restrained sharpening; the result should look like a better capture of the same document, not a processed image.
- **No reconstruction.** If a number or text is covered, blurred, or unreadable in the source, do not infer or recreate it. Mark it open and ask the user for a better source photo or scan.
- **Approval gate.** Never send, submit, upload, or delete anything without the user's explicit "YES." Previews and drafts are fine.
- **Bounded edits.** Touch only what the user asked for; every other field, page, and element stays untouched.

## Workflow

1. **INTAKE** — Collect the highest-resolution source available. Work from copies; keep originals untouched. If the only source has obscured content the user needs, request a new uncovered source photo rather than working from a bad one.
2. **ASSESS** — List what the user wants changed. Check each planned operation against the binding rules; flag and refuse anything that would alter text, layout, or data.
3. **REMASTER** — Apply only these operations: deskew and rotate; perspective correction; crop to the original document boundaries; tone and shadow balancing; restrained sharpening; noise, dust, and scratch removal; ink-tone cleanup; removing form lines behind handwriting while preserving the cursive strokes; merging a signature image into its designated form box, aligned to that box's baseline.
4. **QUALITY CHECK** — Compare against the original: the look must be natural, not over-processed; page count matches; signatures sit on the box baseline; untouched pages and fields remain untouched; handwriting strokes preserved. If the result looks artificial, redo it lighter.
5. **APPROVAL GATE** — Present a before/after preview and wait for the explicit "YES."
6. **ARCHIVE & LOG** — File dual-tier: the full master stays in private storage and is never shared; the outbound copy shows only what the recipient needs (last 4 digits, sensitive IDs blacked out). Respect source-level masking — a document already masking sensitive information may need no second redaction pass. Update the index, log verified facts separately from open items, and end with one immediate next step.

## Failure and Remedy

- Obscured or partially covered number: leave blank, mark open, ask the user for a better source. Never reconstruct.
- Result looks artificial or over-sharpened: discard and redo with lighter treatment.
- Edit creeping beyond the requested field or page: discard the candidate, restart from the pristine original.
- User has not approved: nothing leaves the workspace, regardless of deadline pressure.

## Example

Input: "Remaster this photo of my VA letter — it's dark and tilted."
Output: perspective-corrected, tone-balanced, lightly sharpened version that still reads as the same natural document; a note that the smudged date in paragraph 2 was left as-is and flagged open; before/after preview presented, awaiting "YES."
