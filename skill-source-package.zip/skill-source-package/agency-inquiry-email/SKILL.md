---
name: agency-inquiry-email
description: "Draft a respectful, persistent inquiry email to a government agency or office (housing authority, VA, school, benefits office) about a topic, requesting clarification and the exact documentation required. Use for 'draft an inquiry to X about Y'. Not for replying to an existing email thread."
---

# Agency inquiry email

Draft one inquiry email per request from the topic and/or agency the user provides.

1. Identify the agency, the department if known, and the specific question. If the topic is vague, draft anyway with a bracketed placeholder for the missing detail.
2. Write the email with this structure:
   - Subject: `Inquiry: [Topic] – [Full Name], [Case/Client/Voucher No.]`
   - Greeting to the correct office or `Dear [Caseworker Name / Department],`
   - Identification line with placeholders: `[Full Name]`, `[Date of Birth]`, `[Case/Client/Voucher/Claim No.]`, `[Address]`, `[Phone]`, `[Email]`.
   - One-sentence purpose statement.
   - Numbered questions: what is needed, the exact documents or forms required (form numbers, acceptable formats, whether copies or originals), the deadline, and how and where to submit.
   - If relevant, reference prior contact: `I previously contacted your office on [Date] regarding [Matter] and have not yet received a response.`
   - Request for written confirmation of receipt and a named point of contact, plus a reasonable response date (`by [Date, about 10 business days]`).
   - Polite closing, then `[Full Name]`, `[Signature line]`, `[Phone] | [Email]`.
3. Keep the tone courteous, specific, and firm; no emotional language, accusations, or legal threats. Keep it under about 300 words.
4. Preserve any wording the user supplies; change it only for errors.
5. Add a short follow-up version (for when no reply arrives in 10 business days) below the main draft.
6. Deliver as text in the conversation. Never send email; only create a Gmail draft if the user asks or the request came through the email trigger.
